# ClinicConnect – AI-Integrated Healthcare Management System

> A full-featured React frontend for an AI-powered healthcare platform with patient, doctor, and admin dashboards.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev

# 3. Open in browser
# http://localhost:5173
```

---

## 📁 Folder Structure

```
clinicconnect/
├── index.html                        # HTML entry point
├── vite.config.js                    # Vite configuration
├── package.json                      # Dependencies
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx                      # React entry, BrowserRouter
    ├── App.jsx                       # Route definitions
    │
    ├── styles/                       # CSS design system
    │   ├── global.css                # Tokens, buttons, forms, tables, modals
    │   ├── dashboard.css             # Sidebar, header, stat cards, doctor cards
    │   ├── auth.css                  # Login/signup, role selector, OTP, steps
    │   ├── landing.css               # Navbar, hero, sections, footer
    │   ├── chatbot.css               # Chat UI, typing indicator, spec chips
    │   └── toast.css                 # Toast notification styles
    │
    ├── context/
    │   ├── ToastContext.jsx           # Global toast notification system
    │   └── AuthContext.jsx           # Auth state (login, logout, current user)
    │
    ├── hooks/
    │   └── index.js                  # useToggle, useModal, useCountdown, useScroll, useFilter
    │
    ├── data/
    │   └── mockData.js               # Doctors, appointments, prescriptions, lab reports
    │
    ├── components/
    │   ├── common/
    │   │   ├── Logo.jsx              # Branded logo with theme support
    │   │   ├── Badge.jsx             # Status badge (success/warning/danger/primary)
    │   │   ├── Modal.jsx             # Reusable modal with keyboard/backdrop close
    │   │   ├── Spinner.jsx           # Loading spinner
    │   │   ├── StarRating.jsx        # Interactive/read-only star rating
    │   │   ├── DoctorCard.jsx        # Doctor profile card with booking button
    │   │   ├── BookingModal.jsx      # Appointment booking (mode + date + slot)
    │   │   ├── ConfirmModal.jsx      # Booking confirmation success modal
    │   │   ├── ToastContainer.jsx    # Toast renderer (bottom-right)
    │   │   └── ProtectedRoute.jsx    # Role-based route guard
    │   │
    │   ├── auth/
    │   │   ├── RoleSelector.jsx      # Admin/Doctor/Patient role tabs
    │   │   ├── OTPInput.jsx          # 6-digit OTP input with paste support
    │   │   └── StepIndicator.jsx     # Multi-step progress indicator
    │   │
    │   ├── layout/
    │   │   └── DashboardShell.jsx    # Sidebar + header wrapper for all dashboards
    │   │
    │   └── patient/
    │       └── AIChatbot.jsx         # Claude-powered symptom analysis chatbot
    │
    └── pages/
        ├── LandingPage.jsx           # Marketing homepage
        ├── LoginPage.jsx             # Login with role selector + demo credentials
        ├── SignupPage.jsx            # 3-step signup (Info → Review → OTP)
        ├── patient/
        │   └── PatientDashboard.jsx  # Patient portal (8 sections)
        ├── doctor/
        │   └── DoctorDashboard.jsx   # Doctor portal (7 sections)
        └── admin/
            └── AdminDashboard.jsx    # Admin panel (9 sections)
```

---

## 🔐 Demo Credentials

| Role    | Email                          | Password    |
|---------|--------------------------------|-------------|
| Patient | patient@clinicconnect.com      | patient123  |
| Doctor  | doctor@clinicconnect.com       | doctor123   |
| Admin   | admin@clinicconnect.com        | admin123    |

> Click **"Use Demo Credentials"** on the login page to auto-fill.

---

## 🧭 Routes

| Path         | Page                  | Protected |
|--------------|-----------------------|-----------|
| `/`          | Landing Page          | ❌        |
| `/login`     | Login                 | ❌        |
| `/signup`    | Signup                | ❌        |
| `/patient/*` | Patient Dashboard     | ✅ patient |
| `/doctor/*`  | Doctor Dashboard      | ✅ doctor  |
| `/admin/*`   | Admin Dashboard       | ✅ admin   |

---

## 📋 Dashboard Pages

### 🤕 Patient Dashboard
| Section        | Features                                                      |
|----------------|---------------------------------------------------------------|
| Overview        | Stats, quick tabs (Doctors, Appointments, Prescriptions, Labs)|
| Search Doctors  | Filter by name, specialization, city; book appointment        |
| AI Chatbot      | Claude-powered symptom analysis + specialist recommendation   |
| Appointments    | View, reschedule, cancel upcoming & past appointments         |
| Prescriptions   | View medicines, notes, download PDF                           |
| Lab Reports     | View status, open ready reports                               |
| Feedback        | Rate doctor with star rating + text review                    |
| Settings        | Edit profile, change password                                 |

### 🩺 Doctor Dashboard
| Section        | Features                                                      |
|----------------|---------------------------------------------------------------|
| Overview        | Stats, today's appointments, patient feedback tab             |
| Appointments    | Mark complete, reschedule, cancel                             |
| Patients        | View patient records                                          |
| Prescriptions   | Write new prescriptions with medicine details                 |
| Availability    | Toggle days on/off, set start/end times                       |
| Feedback        | Rating breakdown, individual patient reviews                  |
| Settings        | Edit professional profile, bio                                |

### 🛡️ Admin Dashboard
| Section             | Features                                                  |
|---------------------|-----------------------------------------------------------|
| Overview            | Revenue bar chart, specialization mix, recent activity    |
| Doctor Verification | Approve/reject pending doctor applications                |
| Manage Doctors      | View all doctors, edit, suspend                           |
| Patients            | View all registered patients                              |
| Appointments        | View all platform appointments                            |
| Analytics           | KPIs, monthly appointment chart                           |
| AI Config           | Toggle AI features, edit system prompt, model selection   |
| Notifications       | Platform activity feed                                    |
| Settings            | Platform config, notification preferences                 |

---

## 🤖 AI Chatbot Integration

The AI Chatbot uses the **Anthropic Claude API** (`claude-sonnet-4-20250514`) directly from the browser.

**How it works:**
1. Patient describes symptoms in the chat
2. Claude analyzes them and responds with possible causes + self-care tips
3. Claude returns `SPECIALIST: [name]` at the end of its response
4. A clickable chip appears — tapping it filters the Doctor Search by that specialty

**File:** `src/components/patient/AIChatbot.jsx`

> The API call is made from the browser. In production, proxy this through your backend to protect your API key.

---

## 🎨 Design System

**Fonts:** Sora (display/headings) + DM Sans (body)

**Colors:**
- Primary: `#1a56db` (blue)
- Accent: `#06b6d4` (cyan)
- Success: `#16a34a` | Warning: `#d97706` | Danger: `#dc2626`

**CSS Variables** are defined in `src/styles/global.css` under `:root`.

**Breakpoints:**
- Mobile: `< 480px`
- Tablet: `< 768px`
- Laptop: `< 1024px` (sidebar collapses to drawer)

---

## 🛠️ Tech Stack

| Tool             | Purpose                  |
|------------------|--------------------------|
| React 18         | UI framework             |
| React Router v6  | Client-side routing      |
| Vite 5           | Build tool & dev server  |
| Anthropic API    | AI-powered chatbot       |
| Font Awesome 6   | Icons                    |
| Google Fonts     | Sora + DM Sans           |
| Pure CSS         | No CSS framework used    |

---

## 🏗️ Build for Production

```bash
npm run build
# Output in /dist folder

npm run preview
# Preview production build locally
```

---

## 📝 Notes

- **No backend required** – all data is mocked in `src/data/mockData.js`
- **No CSS framework** – all styles are hand-written CSS variables + utility classes
- **Protected routes** redirect unauthenticated users to `/login`
- To connect a real backend, replace mock data imports with `fetch()` / `axios` calls
- The AI chatbot API key handling should be moved server-side in production

---

*Built for Parul University – AIDS Department | ClinicConnect © 2026*
