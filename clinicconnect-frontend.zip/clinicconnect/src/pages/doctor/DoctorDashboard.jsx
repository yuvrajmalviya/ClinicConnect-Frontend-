import { useState } from 'react'
import DashboardShell from '../../components/layout/DashboardShell'
import Badge from '../../components/common/Badge'
import StarRating from '../../components/common/StarRating'
import { useToast } from '../../context/ToastContext'

const NAV_ITEMS = [
  { key: 'dashboard',     label: 'Dashboard',     faIcon: 'fa-solid fa-house'          },
  { key: 'appointments',  label: 'Appointments',  faIcon: 'fa-solid fa-calendar'       },
  { key: 'patients',      label: 'Patients',      faIcon: 'fa-solid fa-users'          },
  { key: 'prescriptions', label: 'Prescriptions', faIcon: 'fa-solid fa-file-medical'   },
  { key: 'availability',  label: 'Availability',  faIcon: 'fa-solid fa-clock'          },
  { key: 'feedback',      label: 'Feedback',      faIcon: 'fa-solid fa-star'           },
  { key: 'profile',       label: 'Settings',      faIcon: 'fa-solid fa-gear'           },
]

const APPOINTMENTS = [
  { id: 1, patient: 'Amit Kumar',  date: '2026-03-25', time: '10:30 AM', mode: 'Online',    status: 'Booked'    },
  { id: 2, patient: 'Pooja Desai', date: '2026-03-25', time: '3:00 PM',  mode: 'Online',    status: 'Booked'    },
  { id: 3, patient: 'Ravi Nair',   date: '2026-03-10', time: '11:00 AM', mode: 'In-Clinic', status: 'Completed' },
]

const PATIENTS = [
  { id: 1, name: 'Amit Kumar',  age: 28, lastVisit: '2026-03-20', condition: 'Hypertension' },
  { id: 2, name: 'Pooja Desai', age: 35, lastVisit: '2026-03-25', condition: 'Cholesterol'  },
  { id: 3, name: 'Ravi Nair',   age: 52, lastVisit: '2026-03-10', condition: 'Arrhythmia'   },
]

const REVIEWS = [
  { name: 'Amit Kumar',  stars: 5, text: 'Very professional and caring. Explained everything clearly. Highly recommend!' },
  { name: 'Pooja Desai', stars: 4, text: 'Good experience. Waited a bit but the consultation was thorough.' },
  { name: 'Ravi Nair',   stars: 5, text: 'Excellent doctor, very knowledgeable and patient.' },
]

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
const DEFAULT_AVAIL = { Mon: true, Tue: true, Wed: false, Thu: true, Fri: true, Sat: false, Sun: false }

export default function DoctorDashboard() {
  const [page, setPage]         = useState('dashboard')
  const [activeTab, setTab]     = useState('appt')
  const [avail, setAvail]       = useState(DEFAULT_AVAIL)
  const { showToast } = useToast()

  const toggleDay = (day) => setAvail(p => ({ ...p, [day]: !p[day] }))

  return (
    <DashboardShell navItems={NAV_ITEMS} activePage={page} setActivePage={setPage}>

      {/* ── Overview ── */}
      {page === 'dashboard' && (
        <div className="page-section active">
          <div className="stats-grid">
            {[
              { icon: 'fa-solid fa-calendar-day', cl: 'blue',   n: '2',   l: "Today's Appointments" },
              { icon: 'fa-solid fa-users',        cl: 'green',  n: '3',   l: 'Total Patients'       },
              { icon: 'fa-solid fa-star',         cl: 'orange', n: '4.8', l: 'Rating'               },
              { icon: 'fa-solid fa-file-medical', cl: 'cyan',   n: '5',   l: 'Prescriptions'        },
            ].map(s => (
              <div key={s.l} className="stat-card">
                <div className={`stat-icon ${s.cl}`}><i className={s.icon} /></div>
                <div><div className="stat-number">{s.n}</div><div className="stat-label">{s.l}</div></div>
              </div>
            ))}
          </div>

          <div className="card">
            <div className="card-body" style={{ paddingTop: 0 }}>
              <div className="tabs" style={{ marginTop: 0 }}>
                {[['appt', 'Appointments'], ['feedback', 'Patient Feedback']].map(([k, l]) => (
                  <button key={k} className={`tab-btn ${activeTab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{l}</button>
                ))}
              </div>
              {activeTab === 'appt' && (
                <div className="tab-panel active">
                  <div className="table-wrapper">
                    <table><thead><tr><th>Patient</th><th>Date</th><th>Time</th><th>Status</th><th>Actions</th></tr></thead>
                      <tbody>{APPOINTMENTS.map(a => (
                        <tr key={a.id}><td><strong>{a.patient}</strong></td><td>{a.date}</td><td>{a.time}</td>
                          <td><Badge variant={a.status === 'Booked' ? 'primary' : 'success'}>{a.status}</Badge></td>
                          <td><div className="table-actions">
                            {a.status === 'Booked' && <>
                              <button className="btn btn-success-outline btn-sm" onClick={() => showToast('Marked complete', 'success')}><i className="fa-solid fa-check" /> Complete</button>
                              <button className="btn btn-outline btn-sm" onClick={() => showToast('Reschedule coming soon', 'info')}>Reschedule</button>
                              <button className="btn btn-danger btn-sm" onClick={() => showToast('Appointment cancelled', 'warning')}>Cancel</button>
                            </>}
                          </div></td>
                        </tr>
                      ))}</tbody>
                    </table>
                  </div>
                </div>
              )}
              {activeTab === 'feedback' && (
                <div className="tab-panel active">
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                    {REVIEWS.map(r => (
                      <div key={r.name} style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: '1rem' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.45rem' }}>
                          <strong style={{ fontSize: '0.875rem' }}>{r.name}</strong>
                          <StarRating value={r.stars} readOnly size="1rem" />
                        </div>
                        <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{r.text}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── Appointments ── */}
      {page === 'appointments' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-calendar" style={{ color: 'var(--primary)' }} /> All Appointments</span>
            </div>
            <div className="card-body table-wrapper">
              <table><thead><tr><th>Patient</th><th>Date</th><th>Time</th><th>Mode</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>{APPOINTMENTS.map(a => (
                  <tr key={a.id}><td><strong>{a.patient}</strong></td><td>{a.date}</td><td>{a.time}</td>
                    <td><Badge variant="neutral">{a.mode}</Badge></td>
                    <td><Badge variant={a.status === 'Booked' ? 'primary' : 'success'}>{a.status}</Badge></td>
                    <td><div className="table-actions">
                      {a.status === 'Booked' && <>
                        <button className="btn btn-success-outline btn-sm" onClick={() => showToast('Marked complete', 'success')}><i className="fa-solid fa-check" /> Complete</button>
                        <button className="btn btn-danger btn-sm" onClick={() => showToast('Cancelled', 'warning')}>Cancel</button>
                      </>}
                    </div></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Patients ── */}
      {page === 'patients' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-users" style={{ color: 'var(--primary)' }} /> My Patients</span>
            </div>
            <div className="card-body table-wrapper">
              <table><thead><tr><th>Name</th><th>Age</th><th>Last Visit</th><th>Condition</th><th>Actions</th></tr></thead>
                <tbody>{PATIENTS.map(p => (
                  <tr key={p.id}><td><strong>{p.name}</strong></td><td>{p.age}</td><td>{p.lastVisit}</td><td>{p.condition}</td>
                    <td><button className="btn btn-outline btn-sm" onClick={() => showToast(`Opening ${p.name}'s record…`, 'info')}>View Record</button></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Prescriptions ── */}
      {page === 'prescriptions' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-file-medical" style={{ color: 'var(--primary)' }} /> Write Prescription</span>
              <button className="btn btn-primary btn-sm" onClick={() => showToast('Prescription saved!', 'success')}>
                <i className="fa-solid fa-save" /> Save
              </button>
            </div>
            <div className="card-body">
              <div className="form-grid-2">
                <div className="form-group"><label className="form-label">Patient</label>
                  <select className="form-input">{PATIENTS.map(p => <option key={p.id}>{p.name}</option>)}</select>
                </div>
                <div className="form-group"><label className="form-label">Date</label>
                  <input type="date" className="form-input" defaultValue="2026-03-23" />
                </div>
              </div>
              <div className="form-group"><label className="form-label">Diagnosis</label>
                <input type="text" className="form-input" placeholder="Enter diagnosis…" />
              </div>
              <div className="form-group"><label className="form-label">Medicines</label>
                <textarea className="form-input" rows={4} placeholder="Medicine name, dosage, frequency, duration (one per line)…" />
              </div>
              <div className="form-group"><label className="form-label">Additional Notes</label>
                <textarea className="form-input" rows={2} placeholder="Follow-up instructions, dietary advice…" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Availability ── */}
      {page === 'availability' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-clock" style={{ color: 'var(--primary)' }} /> Manage Availability</span>
              <button className="btn btn-primary btn-sm" onClick={() => showToast('Availability saved!', 'success')}>
                <i className="fa-solid fa-save" /> Save
              </button>
            </div>
            <div className="card-body">
              <div className="avail-grid">
                {DAYS.map(day => (
                  <div key={day} className="avail-row">
                    <span style={{ fontWeight: 600, fontSize: '0.9rem', minWidth: 40 }}>{day}</span>
                    {avail[day] && (
                      <div style={{ display: 'flex', gap: '0.65rem', alignItems: 'center', flex: 1, justifyContent: 'center' }}>
                        <input type="time" className="form-input" style={{ width: 'auto' }} defaultValue="10:00" />
                        <span style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>to</span>
                        <input type="time" className="form-input" style={{ width: 'auto' }} defaultValue="17:00" />
                      </div>
                    )}
                    {!avail[day] && <span style={{ flex: 1, textAlign: 'center', fontSize: '0.82rem', color: 'var(--text-muted)' }}>Day off</span>}
                    <label className="toggle">
                      <input type="checkbox" checked={avail[day]} onChange={() => toggleDay(day)} />
                      <span className="toggle-slider" />
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Feedback ── */}
      {page === 'feedback' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-star" style={{ color: 'var(--warning)' }} /> Patient Reviews</span>
            </div>
            <div className="card-body">
              <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
                <div style={{ textAlign: 'center', padding: '1.5rem 2rem', background: 'var(--primary-xlight)', borderRadius: 'var(--radius-lg)', border: '1px solid rgba(26,86,219,0.15)' }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontSize: '2.5rem', fontWeight: 800, color: 'var(--primary)' }}>4.8</div>
                  <StarRating value={5} readOnly size="1.1rem" />
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.3rem' }}>Overall Rating</div>
                </div>
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '0.4rem', justifyContent: 'center', minWidth: 180 }}>
                  {[5, 4, 3, 2, 1].map(n => (
                    <div key={n} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.8rem' }}>
                      <span style={{ minWidth: 18, textAlign: 'right', color: 'var(--text-muted)' }}>{n}</span>
                      <span style={{ color: '#fbbf24', fontSize: '0.75rem' }}>★</span>
                      <div style={{ flex: 1, height: 6, background: 'var(--border)', borderRadius: 99 }}>
                        <div style={{ height: '100%', background: 'var(--primary)', borderRadius: 99, width: [70, 20, 5, 3, 2][5 - n] + '%' }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                {REVIEWS.map(r => (
                  <div key={r.name} style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: '1rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.45rem' }}>
                      <strong style={{ fontSize: '0.875rem' }}>{r.name}</strong>
                      <StarRating value={r.stars} readOnly size="1rem" />
                    </div>
                    <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{r.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Profile ── */}
      {page === 'profile' && (
        <div className="page-section active">
          <div className="profile-header-card">
            <div className="profile-avatar-lg" style={{ background: 'linear-gradient(135deg, #16a34a, #4ade80)' }}>PS</div>
            <div className="profile-header-info">
              <h2>Dr. Priya Sharma</h2>
              <p>doctor@clinicconnect.com</p>
              <p style={{ marginTop: '0.35rem' }}><Badge variant="accent">Cardiologist</Badge></p>
            </div>
            <button className="btn btn-outline btn-sm" style={{ marginLeft: 'auto' }}>
              <i className="fa-solid fa-camera" /> Change Photo
            </button>
          </div>
          <div className="card">
            <div className="card-header">
              <span className="card-title">Edit Profile</span>
              <button className="btn btn-primary btn-sm" onClick={() => showToast('Profile updated!', 'success')}>
                <i className="fa-solid fa-save" /> Save
              </button>
            </div>
            <div className="card-body">
              <div className="form-grid-2">
                {[['Full Name', 'text', 'Dr. Priya Sharma'], ['Email', 'email', 'doctor@clinicconnect.com'], ['Phone', 'tel', '+91 9876543210'], ['Specialization', 'text', 'Cardiologist'], ['Qualification', 'text', 'MBBS, MD (Cardiology)'], ['Experience (years)', 'number', '12']].map(([l, t, v]) => (
                  <div key={l} className="form-group"><label className="form-label">{l}</label><input type={t} className="form-input" defaultValue={v} /></div>
                ))}
              </div>
              <div className="form-group"><label className="form-label">Bio</label>
                <textarea className="form-input" rows={3} defaultValue="Expert cardiologist with 12 years of clinical experience in interventional cardiology and heart disease prevention." />
              </div>
            </div>
          </div>
        </div>
      )}
    </DashboardShell>
  )
}
