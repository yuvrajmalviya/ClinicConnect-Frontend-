import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import Logo from '../components/common/Logo'
import { useScroll } from '../hooks/index'
import '../styles/landing.css'

const FEATURES = [
  { icon: '🧠', title: 'AI Symptom Analysis',   desc: 'Advanced AI analyzes your symptoms and suggests the right specialist instantly.'         },
  { icon: '🔍', title: 'Smart Doctor Matching',  desc: 'Get matched with verified doctors based on specialization, location, and ratings.'       },
  { icon: '📹', title: 'Online Consultation',    desc: 'Connect with doctors via video/audio calls from the comfort of your home.'                },
  { icon: '📋', title: 'E-Prescriptions',        desc: 'Receive digital prescriptions and access them anytime from your dashboard.'               },
  { icon: '🧪', title: 'Lab Test Booking',       desc: 'Book lab tests and receive digital reports directly on your profile.'                     },
  { icon: '📅', title: 'Smart Scheduling',       desc: 'AI-optimized appointment scheduling that respects your time and doctor availability.'     },
]

const MODULES = [
  { icon: '🛡️', title: 'Admin Panel',       desc: 'Manage doctors, patients, analytics, and system configuration.',          role: 'admin'   },
  { icon: '🩺', title: 'Doctor Dashboard',  desc: 'Manage appointments, consultations, prescriptions, and availability.',     role: 'doctor'  },
  { icon: '🤕', title: 'Patient Portal',    desc: 'Search doctors, book appointments, chat with AI, and access records.',     role: 'patient' },
]

const STEPS = [
  { n: '01', title: 'Describe Symptoms',  desc: 'Chat with our AI and describe what you\'re experiencing.'                     },
  { n: '02', title: 'AI Analysis',        desc: 'Our AI determines urgency and identifies the right specialization.'            },
  { n: '03', title: 'Doctor Match',       desc: 'Get recommended verified doctors near you with available slots.'               },
  { n: '04', title: 'Book Appointment',   desc: 'Choose a convenient time and book your consultation instantly.'                },
]

export default function LandingPage() {
  const navigate = useNavigate()
  const scrolled = useScroll(20)
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div className="fade-in">
      {/* ── Navbar ── */}
      <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
        <div className="navbar-inner">
          <Logo />
          <div className="navbar-links">
            {['Features', 'How It Works', 'Modules', 'Contact'].map(l => (
              <a key={l} href={`#${l.toLowerCase().replace(/ /g, '-')}`}>{l}</a>
            ))}
          </div>
          <div className="navbar-actions">
            <Link to="/login"  className="btn btn-outline-gray btn-rounded">Login</Link>
            <Link to="/signup" className="btn btn-primary btn-rounded">Sign Up</Link>
            <button className="mobile-nav-toggle" onClick={() => setMobileOpen(p => !p)}>
              <i className={`fa-solid fa-${mobileOpen ? 'xmark' : 'bars'}`} />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div className={`mobile-menu ${mobileOpen ? 'open' : ''}`}>
        {['Features', 'How It Works', 'Modules', 'Contact'].map(l => (
          <a key={l} href={`#${l.toLowerCase().replace(/ /g, '-')}`} onClick={() => setMobileOpen(false)}>{l}</a>
        ))}
        <div className="mobile-menu-actions">
          <Link to="/login"  className="btn btn-outline-gray btn-rounded" onClick={() => setMobileOpen(false)}>Login</Link>
          <Link to="/signup" className="btn btn-primary btn-rounded"      onClick={() => setMobileOpen(false)}>Sign Up</Link>
        </div>
      </div>

      {/* ── Hero ── */}
      <section className="hero">
        <div className="hero-inner">
          <div className="hero-left">
            <div className="hero-tag">
              <span className="hero-tag-dot" />
              AI-Integrated Healthcare Platform
            </div>
            <h1 className="hero-title">
              Smart Healthcare,<br />
              <span className="hero-accent">Simplified</span>
            </h1>
            <p className="hero-subtitle">
              Connect with verified doctors, get AI-powered symptom analysis, book appointments,
              and manage your health — all in one platform.
            </p>
            <div className="hero-ctas">
              <Link to="/signup" className="btn btn-primary btn-xl btn-rounded">
                Get Started <i className="fa-solid fa-arrow-right" />
              </Link>
              <Link to="/login" className="btn btn-outline-gray btn-xl btn-rounded">
                Login to Dashboard
              </Link>
            </div>
            <div className="hero-stats">
              {[['5,000+','Verified Doctors'], ['120k+','Patients Served'], ['98%','Satisfaction'], ['30+','Specializations']].map(([n, l]) => (
                <div key={l} className="hero-stat-item">
                  <div className="hero-stat-num">{n}</div>
                  <div className="hero-stat-label">{l}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="hero-right">
            <div className="hero-card">
              <div className="hero-card-header">
                <div className="ai-avatar">🤖</div>
                <div>
                  <div className="ai-name">ClinicConnect AI</div>
                  <div className="ai-status">
                    <span className="online-dot" /> Online – Powered by Claude
                  </div>
                </div>
              </div>
              <div className="chat-bubble">
                Hello! I'm your AI health assistant. Describe your symptoms and I'll help you find the right doctor. 😊
              </div>
              <div className="symptom-chips">
                {['Headache', 'Fever', 'Chest Pain', 'Back Pain'].map(s => (
                  <span key={s} className="symptom-chip" onClick={() => navigate('/signup')}>{s}</span>
                ))}
              </div>
              <div className="hero-doc-preview">
                <div className="hero-doc-label">Recommended Specialist</div>
                <div className="hero-doc-card">
                  <div className="mini-avatar">PS</div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: '0.875rem', fontFamily: 'var(--font-display)' }}>Dr. Priya Sharma</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Cardiologist • ⭐ 4.8</div>
                  </div>
                  <button className="btn btn-primary btn-sm" style={{ marginLeft: 'auto' }} onClick={() => navigate('/login')}>
                    Book
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Features ── */}
      <section className="section section-alt" id="features">
        <div className="section-inner">
          <div className="section-header">
            <div className="section-tag">Features</div>
            <h2 className="section-title">Powerful Features</h2>
            <p className="section-subtitle">Everything you need for modern healthcare management, powered by artificial intelligence.</p>
          </div>
          <div className="features-grid">
            {FEATURES.map(f => (
              <div key={f.title} className="feature-card">
                <div className="feature-icon">{f.icon}</div>
                <h3 className="feature-title">{f.title}</h3>
                <p className="feature-desc">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How It Works ── */}
      <section className="section" id="how-it-works">
        <div className="section-inner">
          <div className="section-header">
            <div className="section-tag">Process</div>
            <h2 className="section-title">How It Works</h2>
            <p className="section-subtitle">Four simple steps to better healthcare.</p>
          </div>
          <div className="steps-grid">
            {STEPS.map(s => (
              <div key={s.n} className="step-item">
                <div className="step-circle">{s.n}</div>
                <h4 className="step-title">{s.title}</h4>
                <p className="step-desc">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Modules ── */}
      <section className="section section-alt" id="modules">
        <div className="section-inner">
          <div className="section-header">
            <div className="section-tag">Modules</div>
            <h2 className="section-title">Platform Modules</h2>
            <p className="section-subtitle">Role-based dashboards tailored for every user.</p>
          </div>
          <div className="modules-grid">
            {MODULES.map(m => (
              <div key={m.title} className="module-card">
                <div className="module-icon">{m.icon}</div>
                <h3 className="module-title">{m.title}</h3>
                <p className="module-desc">{m.desc}</p>
                <button className="btn btn-outline btn-full" onClick={() => navigate('/login')}>
                  Open {m.title.split(' ')[0]} Portal
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Contact ── */}
      <section className="section" id="contact">
        <div className="section-inner">
          <div className="section-header">
            <div className="section-tag">Contact</div>
            <h2 className="section-title">Get in Touch</h2>
            <p className="section-subtitle">Have questions? We'd love to hear from you.</p>
          </div>
          <div className="contact-grid">
            {[
              ['✉️', 'Email',   'support@clinicconnect.com'],
              ['📞', 'Phone',   '+91 98765 43210'],
              ['📍', 'Address', 'Parul University, Vadodara, Gujarat, India'],
            ].map(([ic, t, v]) => (
              <div key={t} className="contact-card">
                <div className="contact-icon">{ic}</div>
                <div className="contact-title">{t}</div>
                <div className="contact-value">{v}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className="footer">
        <div className="footer-inner">
          <div className="footer-grid">
            <div>
              <Logo theme="dark" />
              <p>AI-powered healthcare management connecting patients with the right doctors, anywhere.</p>
            </div>
            <div>
              <div className="footer-col-title">Quick Links</div>
              <div className="footer-links">
                {['Features', 'How It Works', 'Contact'].map(l => <a key={l} href="#">{l}</a>)}
              </div>
            </div>
            <div>
              <div className="footer-col-title">Legal</div>
              <div className="footer-links">
                {['Privacy Policy', 'Terms of Service', 'HIPAA Compliance'].map(l => <a key={l} href="#">{l}</a>)}
              </div>
            </div>
            <div>
              <div className="footer-col-title">Dashboards</div>
              <div className="footer-links">
                <Link to="/login">Patient Portal</Link>
                <Link to="/login">Doctor Portal</Link>
                <Link to="/login">Admin Panel</Link>
              </div>
            </div>
          </div>
          <hr className="footer-divider" />
          <div className="footer-bottom">
            <span>© 2026 ClinicConnect. All rights reserved.</span>
            <span>Parul University – AIDS Department</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
