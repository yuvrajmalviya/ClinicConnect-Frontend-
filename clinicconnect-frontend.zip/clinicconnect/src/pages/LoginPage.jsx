import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import Logo from '../components/common/Logo'
import RoleSelector from '../components/auth/RoleSelector'
import Spinner from '../components/common/Spinner'
import { DEMO_CREDENTIALS } from '../data/mockData'
import '../styles/auth.css'

const ROLES = [
  { key: 'admin',   label: 'Admin',   faIcon: 'fa-solid fa-shield-halved' },
  { key: 'doctor',  label: 'Doctor',  faIcon: 'fa-solid fa-stethoscope'   },
  { key: 'patient', label: 'Patient', faIcon: 'fa-solid fa-user-injured'  },
]

const REDIRECT = {
  admin:   '/admin',
  doctor:  '/doctor',
  patient: '/patient',
}

export default function LoginPage() {
  const [role,     setRole]     = useState('patient')
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [showPw,   setShowPw]   = useState(false)
  const [loading,  setLoading]  = useState(false)
  const [errors,   setErrors]   = useState({})

  const { login }     = useAuth()
  const { showToast } = useToast()
  const navigate      = useNavigate()

  const validate = () => {
    const e = {}
    if (!email)              e.email    = 'Email is required'
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = 'Invalid email format'
    if (!password)           e.password = 'Password is required'
    else if (password.length < 6)         e.password = 'Min 6 characters'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!validate()) return
    setLoading(true)
    setTimeout(() => {
      login(role)
      showToast(`Welcome back! Logged in as ${ROLES.find(r => r.key === role)?.label}`, 'success')
      navigate(REDIRECT[role])
    }, 900)
  }

  const fillDemo = () => {
    const creds = DEMO_CREDENTIALS[role]
    setEmail(creds.email)
    setPassword(creds.password)
    setErrors({})
    showToast('Demo credentials filled!', 'info')
  }

  return (
    <div className="auth-page">
      <Link to="/" className="auth-logo">
        <Logo />
      </Link>

      <div className="auth-card fade-up">
        <h1 className="auth-title">Welcome Back</h1>
        <p className="auth-subtitle">Select your role and log in to continue</p>

        <RoleSelector roles={ROLES} selected={role} onChange={r => { setRole(r); setErrors({}) }} />

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <input
              type="email"
              className="form-input"
              placeholder="you@example.com"
              value={email}
              onChange={e => { setEmail(e.target.value); setErrors(p => ({ ...p, email: '' })) }}
              autoComplete="email"
            />
            {errors.email && <div className="form-error"><i className="fa-solid fa-circle-exclamation" /> {errors.email}</div>}
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <div style={{ position: 'relative' }}>
              <input
                type={showPw ? 'text' : 'password'}
                className="form-input"
                placeholder="Enter your password"
                value={password}
                onChange={e => { setPassword(e.target.value); setErrors(p => ({ ...p, password: '' })) }}
                autoComplete="current-password"
                style={{ paddingRight: '2.5rem' }}
              />
              <span
                onClick={() => setShowPw(p => !p)}
                style={{ position: 'absolute', right: '0.85rem', top: '50%', transform: 'translateY(-50%)', cursor: 'pointer', color: 'var(--text-muted)', fontSize: '0.85rem' }}
              >
                <i className={`fa-solid fa-eye${showPw ? '-slash' : ''}`} />
              </span>
            </div>
            {errors.password && <div className="form-error"><i className="fa-solid fa-circle-exclamation" /> {errors.password}</div>}
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '1.25rem' }}>
            <a href="#" style={{ fontSize: '0.82rem', color: 'var(--primary)', fontWeight: 600 }}>Forgot password?</a>
          </div>

          <button type="submit" className="btn btn-primary btn-full btn-lg" disabled={loading}>
            {loading
              ? <><Spinner /> Logging in...</>
              : <><i className="fa-solid fa-right-to-bracket" /> Login as {ROLES.find(r => r.key === role)?.label}</>
            }
          </button>
        </form>

        <div style={{ marginTop: '0.75rem' }}>
          <button className="btn btn-outline-gray btn-full btn-lg" onClick={fillDemo} disabled={loading}>
            <i className="fa-solid fa-wand-magic-sparkles" /> Use Demo Credentials
          </button>
        </div>

        <p style={{ textAlign: 'center', fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '1.5rem' }}>
          Don't have an account?{' '}
          <Link to="/signup" style={{ color: 'var(--primary)', fontWeight: 600 }}>Sign up free</Link>
        </p>
      </div>
    </div>
  )
}
