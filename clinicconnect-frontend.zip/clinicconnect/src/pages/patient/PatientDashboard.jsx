import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import DashboardShell from '../../components/layout/DashboardShell'
import DoctorCard from '../../components/common/DoctorCard'
import BookingModal from '../../components/common/BookingModal'
import ConfirmModal from '../../components/common/ConfirmModal'
import AIChatbot from '../../components/patient/AIChatbot'
import StarRating from '../../components/common/StarRating'
import Badge from '../../components/common/Badge'
import { useToast } from '../../context/ToastContext'
import { useModal, useFilter } from '../../hooks/index'
import { DOCTORS, SPECIALIZATIONS, APPOINTMENTS, PRESCRIPTIONS, LAB_REPORTS } from '../../data/mockData'

const NAV_ITEMS = [
  { key: 'dashboard',    label: 'Dashboard',     faIcon: 'fa-solid fa-house'         },
  { key: 'search',       label: 'Search Doctors', faIcon: 'fa-solid fa-magnifying-glass' },
  { key: 'chatbot',      label: 'AI Chatbot',     faIcon: 'fa-solid fa-robot'         },
  { key: 'appointments', label: 'Appointments',   faIcon: 'fa-solid fa-calendar'      },
  { key: 'prescriptions',label: 'Prescriptions',  faIcon: 'fa-solid fa-file-medical'  },
  { key: 'labreports',   label: 'Lab Reports',    faIcon: 'fa-solid fa-flask'         },
  { key: 'feedback',     label: 'Feedback',       faIcon: 'fa-solid fa-star'          },
  { key: 'profile',      label: 'Settings',       faIcon: 'fa-solid fa-gear'          },
]

export default function PatientDashboard() {
  const [page,      setPage]    = useState('dashboard')
  const [activeTab, setTab]     = useState('search')
  const [rating,    setRating]  = useState(4)
  const [specFilter, setSpecFilter] = useState('')
  const navigate = useNavigate()

  const { showToast } = useToast()
  const booking = useModal()
  const confirm = useModal()

  const { query, setQuery, spec, setSpec, city, setCity, filtered } = useFilter(
    DOCTORS,
    (doc, { query, spec, city }) =>
      (!query || doc.name.toLowerCase().includes(query.toLowerCase()) || doc.spec.toLowerCase().includes(query.toLowerCase())) &&
      (!spec  || doc.spec === spec) &&
      (!city  || doc.city.toLowerCase().includes(city.toLowerCase()))
  )

  const handleBook = (doc) => booking.open(doc)
  const handleConfirm = ({ doctor, date, slot, mode }) => {
    booking.close()
    confirm.open(`Appointment with ${doctor.name} on ${date} at ${slot} (${mode}).`)
  }
  const handleSpecialistClick = (spec) => {
    setSpec(spec)
    setPage('search')
    showToast(`Showing ${spec} doctors`, 'info')
  }

  return (
    <DashboardShell navItems={NAV_ITEMS} activePage={page} setActivePage={setPage}>

      {/* ── Overview ── */}
      {page === 'dashboard' && (
        <div className="page-section active">
          <div className="stats-grid">
            {[
              { icon: 'fa-solid fa-calendar',      cl: 'blue',   n: '1', l: 'Upcoming Appointments' },
              { icon: 'fa-solid fa-file-medical',  cl: 'green',  n: '1', l: 'Prescriptions'         },
              { icon: 'fa-solid fa-flask',         cl: 'cyan',   n: '2', l: 'Lab Reports'           },
              { icon: 'fa-solid fa-star',          cl: 'orange', n: '1', l: 'Feedback Given'        },
            ].map(s => (
              <div key={s.l} className="stat-card">
                <div className={`stat-icon ${s.cl}`}><i className={s.icon} /></div>
                <div><div className="stat-number">{s.n}</div><div className="stat-label">{s.l}</div></div>
              </div>
            ))}
          </div>

          <div className="card">
            <div className="card-body" style={{ paddingTop: 0 }}>
              <div className="tabs" style={{ marginTop: 0 }}>
                {[['search', 'Find Doctors'], ['appt', 'Appointments'], ['rx', 'Prescriptions'], ['lab', 'Lab Reports']].map(([k, l]) => (
                  <button key={k} className={`tab-btn ${activeTab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{l}</button>
                ))}
              </div>

              {activeTab === 'search' && (
                <div className="tab-panel active">
                  <div className="doctors-grid">
                    {DOCTORS.slice(0, 4).map(d => <DoctorCard key={d.id} doc={d} onBook={handleBook} />)}
                  </div>
                </div>
              )}
              {activeTab === 'appt' && (
                <div className="tab-panel active">
                  <div className="table-wrapper">
                    <table><thead><tr><th>Doctor</th><th>Specialization</th><th>Date</th><th>Time</th><th>Mode</th><th>Status</th></tr></thead>
                      <tbody>{APPOINTMENTS.map(a => (
                        <tr key={a.id}><td><strong>{a.doctor}</strong></td><td>{a.spec}</td><td>{a.date}</td><td>{a.time}</td><td>{a.mode}</td>
                          <td><Badge variant={a.status === 'Booked' ? 'primary' : 'success'}>{a.status}</Badge></td></tr>
                      ))}</tbody>
                    </table>
                  </div>
                </div>
              )}
              {activeTab === 'rx' && (
                <div className="tab-panel active">
                  <div className="table-wrapper">
                    <table><thead><tr><th>Doctor</th><th>Date</th><th>Medicines</th><th>Action</th></tr></thead>
                      <tbody>{PRESCRIPTIONS.map(r => (
                        <tr key={r.id}><td>{r.doctor}</td><td>{r.date}</td>
                          <td>{r.medicines.map(m => m.name).join(', ')}</td>
                          <td><button className="btn btn-outline btn-sm" onClick={() => showToast('Downloading PDF…', 'info')}><i className="fa-solid fa-download" /> PDF</button></td></tr>
                      ))}</tbody>
                    </table>
                  </div>
                </div>
              )}
              {activeTab === 'lab' && (
                <div className="tab-panel active">
                  <div className="table-wrapper">
                    <table><thead><tr><th>Test</th><th>Date</th><th>Lab</th><th>Status</th></tr></thead>
                      <tbody>{LAB_REPORTS.map(r => (
                        <tr key={r.id}><td><strong>{r.test}</strong></td><td>{r.date}</td><td>{r.lab}</td>
                          <td><Badge variant={r.status === 'Ready' ? 'success' : 'warning'}>{r.status}</Badge></td></tr>
                      ))}</tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── Search Doctors ── */}
      {page === 'search' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-magnifying-glass" style={{ color: 'var(--primary)' }} /> Find a Doctor</span>
            </div>
            <div className="card-body">
              <div className="search-filters">
                <div className="search-input-wrap" style={{ flex: 2, minWidth: 200 }}>
                  <span className="search-icon"><i className="fa-solid fa-magnifying-glass" /></span>
                  <input className="form-input" placeholder="Search name or specialization…" value={query} onChange={e => setQuery(e.target.value)} />
                </div>
                <select className="form-input" style={{ flex: 1, minWidth: 160 }} value={spec} onChange={e => setSpec(e.target.value)}>
                  <option value="">All Specializations</option>
                  {SPECIALIZATIONS.map(s => <option key={s}>{s}</option>)}
                </select>
                <input className="form-input" style={{ flex: 1, minWidth: 130 }} placeholder="Filter by city…" value={city} onChange={e => setCity(e.target.value)} />
              </div>
              <div className="doctors-grid">
                {filtered.length
                  ? filtered.map(d => <DoctorCard key={d.id} doc={d} onBook={handleBook} />)
                  : <p style={{ color: 'var(--text-muted)', padding: '1rem 0' }}>No doctors found matching your filters.</p>
                }
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── AI Chatbot ── */}
      {page === 'chatbot' && (
        <div className="page-section active">
          <AIChatbot onSpecialistClick={handleSpecialistClick} />
        </div>
      )}

      {/* ── Appointments ── */}
      {page === 'appointments' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-calendar" style={{ color: 'var(--primary)' }} /> My Appointments</span>
              <button className="btn btn-primary btn-sm" onClick={() => setPage('search')}>
                <i className="fa-solid fa-plus" /> New Appointment
              </button>
            </div>
            <div className="card-body table-wrapper">
              <table><thead><tr><th>Doctor</th><th>Specialization</th><th>Date</th><th>Time</th><th>Mode</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                  {APPOINTMENTS.map(a => (
                    <tr key={a.id}>
                      <td><strong>{a.doctor}</strong></td><td>{a.spec}</td><td>{a.date}</td><td>{a.time}</td>
                      <td><Badge variant="neutral">{a.mode}</Badge></td>
                      <td><Badge variant={a.status === 'Booked' ? 'primary' : 'success'}>{a.status}</Badge></td>
                      <td><div className="table-actions">
                        {a.status === 'Booked' && <>
                          <button className="btn btn-outline btn-sm" onClick={() => showToast('Reschedule coming soon', 'info')}>Reschedule</button>
                          <button className="btn btn-danger btn-sm" onClick={() => showToast('Appointment cancelled', 'warning')}>Cancel</button>
                        </>}
                        {a.status === 'Completed' && <button className="btn btn-outline btn-sm" onClick={() => setPage('feedback')}>Rate</button>}
                      </div></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Prescriptions ── */}
      {page === 'prescriptions' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-file-medical" style={{ color: 'var(--primary)' }} /> My Prescriptions</span>
            </div>
            <div className="card-body">
              {PRESCRIPTIONS.map(rx => (
                <div key={rx.id} className="rx-card">
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem', flexWrap: 'wrap', gap: '0.5rem' }}>
                    <div>
                      <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{rx.doctor} – {rx.spec}</h4>
                      <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.15rem' }}>Date: {rx.date}</p>
                    </div>
                    <button className="btn btn-outline btn-sm" onClick={() => showToast('Downloading PDF…', 'info')}>
                      <i className="fa-solid fa-download" /> Download PDF
                    </button>
                  </div>
                  <div className="rx-medicine-list">
                    <div style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>Medicines</div>
                    {rx.medicines.map(m => (
                      <div key={m.name} className="rx-medicine-item">
                        <span style={{ color: 'var(--primary)', marginTop: '2px' }}>•</span>
                        <span><strong>{m.name}</strong> – {m.instruction} – {m.duration}</span>
                      </div>
                    ))}
                    <div style={{ marginTop: '0.75rem', fontSize: '0.8rem', color: 'var(--text-secondary)', paddingTop: '0.6rem', borderTop: '1px solid var(--border)' }}>
                      <strong>Notes:</strong> {rx.notes}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Lab Reports ── */}
      {page === 'labreports' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-flask" style={{ color: 'var(--primary)' }} /> Lab Reports</span>
            </div>
            <div className="card-body table-wrapper">
              <table><thead><tr><th>Test Name</th><th>Date</th><th>Lab</th><th>Ordered By</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                  {LAB_REPORTS.map(r => (
                    <tr key={r.id}>
                      <td><strong>{r.test}</strong></td><td>{r.date}</td><td>{r.lab}</td><td>{r.orderedBy}</td>
                      <td><Badge variant={r.status === 'Ready' ? 'success' : 'warning'}>{r.status}</Badge></td>
                      <td>
                        {r.status === 'Ready'
                          ? <button className="btn btn-outline btn-sm" onClick={() => showToast('Opening report…', 'info')}><i className="fa-solid fa-eye" /> View</button>
                          : <button className="btn btn-outline-gray btn-sm" disabled>Awaiting</button>
                        }
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Feedback ── */}
      {page === 'feedback' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-star" style={{ color: 'var(--warning)' }} /> Give Feedback</span>
            </div>
            <div className="card-body">
              <div className="form-group">
                <label className="form-label">Select Doctor</label>
                <select className="form-input">
                  {APPOINTMENTS.map(a => <option key={a.id}>{a.doctor} – {a.spec}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Rating</label>
                <StarRating value={rating} onChange={setRating} />
              </div>
              <div className="form-group">
                <label className="form-label">Your Feedback</label>
                <textarea className="form-input" rows={4} placeholder="Share your experience with this doctor…" />
              </div>
              <button className="btn btn-primary" onClick={() => showToast('Feedback submitted! Thank you.', 'success')}>
                <i className="fa-solid fa-paper-plane" /> Submit Feedback
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── Profile / Settings ── */}
      {page === 'profile' && (
        <div className="page-section active">
          <div className="profile-header-card">
            <div className="profile-avatar-lg">AK</div>
            <div className="profile-header-info">
              <h2>Amit Kumar</h2>
              <p>patient@clinicconnect.com</p>
              <p style={{ marginTop: '0.35rem' }}><Badge variant="primary">Patient</Badge></p>
            </div>
            <button className="btn btn-outline btn-sm" style={{ marginLeft: 'auto' }} onClick={() => showToast('Photo upload coming soon', 'info')}>
              <i className="fa-solid fa-camera" /> Change Photo
            </button>
          </div>
          <div className="card">
            <div className="card-header">
              <span className="card-title">Edit Profile</span>
              <button className="btn btn-primary btn-sm" onClick={() => showToast('Profile updated!', 'success')}>
                <i className="fa-solid fa-save" /> Save Changes
              </button>
            </div>
            <div className="card-body">
              <div className="form-grid-2">
                {[['Full Name', 'text', 'Amit Kumar'], ['Email', 'email', 'patient@clinicconnect.com'], ['Phone', 'tel', '+91 9876543210'], ['Age', 'number', '28']].map(([l, t, v]) => (
                  <div key={l} className="form-group"><label className="form-label">{l}</label><input type={t} className="form-input" defaultValue={v} /></div>
                ))}
                <div className="form-group"><label className="form-label">Gender</label>
                  <select className="form-input"><option>Male</option><option>Female</option><option>Other</option></select>
                </div>
                <div className="form-group"><label className="form-label">City</label><input type="text" className="form-input" defaultValue="Mumbai" /></div>
              </div>
              <div className="form-group"><label className="form-label">Address</label><input type="text" className="form-input" defaultValue="123, Marine Lines, Mumbai, Maharashtra" /></div>
              <hr className="divider" />
              <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: '1rem' }}>Change Password</h4>
              <div className="form-grid-2">
                <div className="form-group"><label className="form-label">Current Password</label><input type="password" className="form-input" placeholder="••••••••" /></div>
                <div className="form-group"><label className="form-label">New Password</label><input type="password" className="form-input" placeholder="••••••••" /></div>
              </div>
            </div>
          </div>
        </div>
      )}

      <BookingModal open={booking.isOpen} doctor={booking.data} onClose={booking.close} onConfirm={handleConfirm} />
      <ConfirmModal
        open={confirm.isOpen}
        details={confirm.data}
        onClose={confirm.close}
        onViewAppointments={() => { confirm.close(); setPage('appointments') }}
      />
    </DashboardShell>
  )
}
