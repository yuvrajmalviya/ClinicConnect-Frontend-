import { useState } from 'react'
import DashboardShell from '../../components/layout/DashboardShell'
import Badge from '../../components/common/Badge'
import { useToast } from '../../context/ToastContext'
import { DOCTORS, REVENUE_DATA, PENDING_VERIFICATIONS, ADMIN_STATS } from '../../data/mockData'

const NAV_ITEMS = [
  { key: 'overview',      label: 'Overview',           faIcon: 'fa-solid fa-chart-pie',      badge: null },
  { key: 'verification',  label: 'Doctor Verification', faIcon: 'fa-solid fa-shield-halved',  badge: 2    },
  { key: 'doctors',       label: 'Manage Doctors',      faIcon: 'fa-solid fa-user-doctor',    badge: null },
  { key: 'patients',      label: 'Patients',            faIcon: 'fa-solid fa-users',          badge: null },
  { key: 'appointments',  label: 'Appointments',        faIcon: 'fa-solid fa-calendar',       badge: null },
  { key: 'analytics',     label: 'Analytics',           faIcon: 'fa-solid fa-chart-line',     badge: null },
  { key: 'aiconfig',      label: 'AI Config',           faIcon: 'fa-solid fa-robot',          badge: null },
  { key: 'notifications', label: 'Notifications',       faIcon: 'fa-solid fa-bell',           badge: 5    },
  { key: 'settings',      label: 'Settings',            faIcon: 'fa-solid fa-gear',           badge: null },
]

const ALL_APPOINTMENTS = [
  { patient: 'Amit Kumar',  doctor: 'Dr. Priya Sharma', date: '2026-03-25', mode: 'Online',    status: 'Booked',    badge: 'primary' },
  { patient: 'Pooja Desai', doctor: 'Dr. Priya Sharma', date: '2026-03-25', mode: 'Online',    status: 'Booked',    badge: 'primary' },
  { patient: 'Ravi Nair',   doctor: 'Dr. Anita Patel',  date: '2026-03-10', mode: 'In-Clinic', status: 'Completed', badge: 'success' },
]

const PATIENTS_LIST = [
  { name: 'Amit Kumar',    email: 'patient@clinicconnect.com', city: 'Mumbai',    date: '2026-01-15' },
  { name: 'Pooja Desai',   email: 'pooja@example.com',         city: 'Pune',      date: '2026-02-03' },
  { name: 'Ravi Nair',     email: 'ravi@example.com',          city: 'Kochi',     date: '2026-02-20' },
  { name: 'Ananya Singh',  email: 'ananya@example.com',        city: 'Delhi',     date: '2026-03-01' },
]

const NOTIFICATIONS = [
  { icon: '🛡️', title: 'New doctor verification request', desc: 'Dr. Arjun Mehta applied for verification', time: '2 min ago', badge: 'primary'  },
  { icon: '📅', title: 'New appointment booked',           desc: 'Amit Kumar booked with Dr. Priya Sharma',  time: '15 min ago', badge: 'success' },
  { icon: '🧪', title: 'Lab report ready',                 desc: 'CBC report for Amit Kumar is ready',        time: '1 hr ago',   badge: 'success' },
  { icon: '⭐', title: 'New review received',              desc: 'Dr. Priya Sharma received a 5-star review', time: '2 hr ago',   badge: 'warning' },
  { icon: '🛡️', title: 'Another verification request',    desc: 'Dr. Sunita Roy applied for verification',   time: '3 hr ago',   badge: 'primary' },
]

const SPEC_MIX = [
  { name: 'Cardiologist',     pct: 25, color: 'var(--primary)' },
  { name: 'Dermatologist',    pct: 18, color: 'var(--accent)'  },
  { name: 'Pediatrician',     pct: 22, color: 'var(--success)' },
  { name: 'Neurologist',      pct: 15, color: 'var(--warning)' },
  { name: 'Other',            pct: 20, color: '#8b5cf6'        },
]

export default function AdminDashboard() {
  const [page, setPage] = useState('overview')
  const [aiEnabled, setAiEnabled] = useState(true)
  const [webSearch, setWebSearch] = useState(false)
  const { showToast } = useToast()

  const maxRev = Math.max(...REVENUE_DATA.map(d => d.value))

  return (
    <DashboardShell navItems={NAV_ITEMS} activePage={page} setActivePage={setPage}>

      {/* ── Overview ── */}
      {page === 'overview' && (
        <div className="page-section active">
          <div className="stats-grid">
            {[
              { icon: 'fa-solid fa-user-doctor',  cl: 'blue',   n: ADMIN_STATS.totalDoctors,          l: 'Total Doctors'          },
              { icon: 'fa-solid fa-users',        cl: 'green',  n: ADMIN_STATS.totalPatients,         l: 'Total Patients'         },
              { icon: 'fa-solid fa-calendar-day', cl: 'cyan',   n: ADMIN_STATS.todayAppointments,     l: "Today's Appointments"   },
              { icon: 'fa-solid fa-shield-halved',cl: 'orange', n: ADMIN_STATS.pendingVerifications,  l: 'Pending Verifications'  },
            ].map(s => (
              <div key={s.l} className="stat-card">
                <div className={`stat-icon ${s.cl}`}><i className={s.icon} /></div>
                <div><div className="stat-number">{s.n}</div><div className="stat-label">{s.l}</div></div>
              </div>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '3fr 2fr', gap: '1.5rem', marginBottom: '1.5rem' }}>
            {/* Revenue Chart */}
            <div className="card">
              <div className="card-header">
                <span className="card-title"><i className="fa-solid fa-chart-line" style={{ color: 'var(--primary)' }} /> Revenue Overview</span>
                <span style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--success)' }}>+12% this month</span>
              </div>
              <div className="card-body">
                <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'flex-end', height: 160 }}>
                  {REVENUE_DATA.map(d => (
                    <div key={d.month} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.3rem', height: '100%', justifyContent: 'flex-end' }}>
                      <span style={{ fontSize: '0.6rem', color: 'var(--text-muted)', fontWeight: 600 }}>{d.value}k</span>
                      <div style={{ width: '100%', background: 'linear-gradient(180deg, var(--primary), var(--accent))', borderRadius: '5px 5px 0 0', height: `${(d.value / maxRev) * 100}%`, transition: 'height 0.6s ease' }} />
                      <span style={{ fontSize: '0.6rem', color: 'var(--text-muted)' }}>{d.month}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Specialization Mix */}
            <div className="card">
              <div className="card-header"><span className="card-title"><i className="fa-solid fa-chart-pie" style={{ color: 'var(--primary)' }} /> Specialization Mix</span></div>
              <div className="card-body">
                {SPEC_MIX.map(s => (
                  <div key={s.name} style={{ marginBottom: '0.7rem' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', marginBottom: '0.25rem' }}>
                      <span style={{ fontWeight: 600 }}>{s.name}</span>
                      <span style={{ color: 'var(--text-muted)' }}>{s.pct}%</span>
                    </div>
                    <div style={{ height: 6, background: 'var(--border)', borderRadius: 99 }}>
                      <div style={{ height: '100%', width: `${s.pct}%`, background: s.color, borderRadius: 99, transition: 'width 0.6s ease' }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="card">
            <div className="card-header"><span className="card-title">📋 Recent Activity</span></div>
            <div className="card-body table-wrapper">
              <table><thead><tr><th>Event</th><th>User</th><th>Time</th><th>Status</th></tr></thead>
                <tbody>
                  {[
                    ['New doctor registration', 'Dr. Arjun Mehta',   '2 min ago',  'warning'],
                    ['Appointment booked',      'Amit Kumar',         '15 min ago', 'success'],
                    ['Lab report uploaded',     'Apollo Diagnostics', '1 hr ago',   'success'],
                    ['Verification request',    'Dr. Sunita Roy',     '3 hr ago',   'warning'],
                  ].map(([ev, user, time, badge]) => (
                    <tr key={ev + user}>
                      <td>{ev}</td><td><strong>{user}</strong></td>
                      <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>{time}</td>
                      <td><Badge variant={badge}>{badge === 'warning' ? 'Pending' : 'Done'}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Doctor Verification ── */}
      {page === 'verification' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-shield-halved" style={{ color: 'var(--primary)' }} /> Doctor Verification Queue</span>
              <Badge variant="warning">{PENDING_VERIFICATIONS.length} Pending</Badge>
            </div>
            <div className="card-body">
              {PENDING_VERIFICATIONS.map(d => (
                <div key={d.name} style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '1.25rem', marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.85rem', gap: '0.75rem', flexWrap: 'wrap' }}>
                    <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
                      <div className="doctor-avatar" style={{ width: 46, height: 46 }}>{d.initials}</div>
                      <div>
                        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{d.name}</div>
                        <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{d.spec}</div>
                      </div>
                    </div>
                    <Badge variant="warning">Pending Review</Badge>
                  </div>
                  <div style={{ display: 'flex', gap: '1.25rem', fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '1rem', flexWrap: 'wrap' }}>
                    <span>🎓 {d.qual}</span>
                    <span>📋 Reg: {d.reg}</span>
                    <span>⏱ {d.exp} experience</span>
                  </div>
                  <div style={{ display: 'flex', gap: '0.75rem' }}>
                    <button className="btn btn-success-outline btn-sm" onClick={() => showToast(`${d.name} approved!`, 'success')}>
                      <i className="fa-solid fa-check" /> Approve
                    </button>
                    <button className="btn btn-danger btn-sm" onClick={() => showToast(`${d.name} rejected`, 'warning')}>
                      <i className="fa-solid fa-xmark" /> Reject
                    </button>
                    <button className="btn btn-outline-gray btn-sm" onClick={() => showToast('Opening documents…', 'info')}>
                      <i className="fa-solid fa-file" /> View Docs
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Manage Doctors ── */}
      {page === 'doctors' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-user-doctor" style={{ color: 'var(--primary)' }} /> Manage Doctors</span>
              <button className="btn btn-primary btn-sm" onClick={() => showToast('Add doctor coming soon', 'info')}>
                <i className="fa-solid fa-plus" /> Add Doctor
              </button>
            </div>
            <div className="card-body table-wrapper">
              <table><thead><tr><th>Name</th><th>Specialization</th><th>City</th><th>Rating</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>{DOCTORS.map(d => (
                  <tr key={d.id}>
                    <td><strong>{d.name}</strong></td><td>{d.spec}</td><td>{d.city}</td>
                    <td>⭐ {d.rating}</td>
                    <td><Badge variant="success">Active</Badge></td>
                    <td><div className="table-actions">
                      <button className="btn btn-outline btn-sm" onClick={() => showToast(`Editing ${d.name}`, 'info')}>Edit</button>
                      <button className="btn btn-danger btn-sm" onClick={() => showToast(`${d.name} suspended`, 'warning')}>Suspend</button>
                    </div></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Patients ── */}
      {page === 'patients' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header"><span className="card-title"><i className="fa-solid fa-users" style={{ color: 'var(--primary)' }} /> All Patients</span></div>
            <div className="card-body table-wrapper">
              <table><thead><tr><th>Name</th><th>Email</th><th>City</th><th>Registered</th><th>Actions</th></tr></thead>
                <tbody>{PATIENTS_LIST.map(p => (
                  <tr key={p.name}><td><strong>{p.name}</strong></td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{p.email}</td>
                    <td>{p.city}</td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{p.date}</td>
                    <td><button className="btn btn-outline btn-sm" onClick={() => showToast(`Viewing ${p.name}'s profile`, 'info')}>View</button></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Appointments ── */}
      {page === 'appointments' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header"><span className="card-title"><i className="fa-solid fa-calendar" style={{ color: 'var(--primary)' }} /> All Appointments</span></div>
            <div className="card-body table-wrapper">
              <table><thead><tr><th>Patient</th><th>Doctor</th><th>Date</th><th>Mode</th><th>Status</th></tr></thead>
                <tbody>{ALL_APPOINTMENTS.map((a, i) => (
                  <tr key={i}><td>{a.patient}</td><td>{a.doctor}</td><td>{a.date}</td>
                    <td><Badge variant="neutral">{a.mode}</Badge></td>
                    <td><Badge variant={a.badge}>{a.status}</Badge></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ── Analytics ── */}
      {page === 'analytics' && (
        <div className="page-section active">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: '1rem', marginBottom: '1.5rem' }}>
            {[
              ['Total Revenue', ADMIN_STATS.totalRevenue, '+12% vs last month', 'var(--primary)'],
              ['Avg Rating',    ADMIN_STATS.avgRating + ' ⭐', '+0.2 this month', 'var(--success)'],
              ['Active Doctors','6', '2 pending verification', 'var(--accent)'],
              ['New Patients',  '24', 'This month',            'var(--warning)'],
            ].map(([l, v, s, c]) => (
              <div key={l} className="stat-card" style={{ flexDirection: 'column', alignItems: 'flex-start', gap: '0.3rem' }}>
                <div style={{ fontSize: '0.78rem', fontWeight: 600, color: 'var(--text-muted)' }}>{l}</div>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.85rem', fontWeight: 800, color: c }}>{v}</div>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{s}</div>
              </div>
            ))}
          </div>
          <div className="card">
            <div className="card-header"><span className="card-title">📅 Monthly Appointments</span></div>
            <div className="card-body">
              <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'flex-end', height: 160 }}>
                {[45, 55, 62, 78, 88, 95, 82, 110, 98, 125, 118, 142].map((v, i) => (
                  <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.2rem', height: '100%', justifyContent: 'flex-end' }}>
                    <div style={{ width: '100%', background: 'linear-gradient(180deg,var(--primary),var(--accent))', borderRadius: '4px 4px 0 0', height: `${(v / 142) * 100}%` }} />
                    <span style={{ fontSize: '0.55rem', color: 'var(--text-muted)' }}>
                      {['J','F','M','A','M','J','J','A','S','O','N','D'][i]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── AI Config ── */}
      {page === 'aiconfig' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-robot" style={{ color: 'var(--primary)' }} /> AI Configuration</span>
              <button className="btn btn-primary btn-sm" onClick={() => showToast('Settings saved!', 'success')}>
                <i className="fa-solid fa-save" /> Save
              </button>
            </div>
            <div className="card-body">
              <div className="form-group">
                <label className="form-label">AI Model</label>
                <select className="form-input"><option>claude-sonnet-4-20250514</option><option>claude-opus-4-6</option></select>
              </div>
              <div className="form-group">
                <label className="form-label">Max Response Tokens</label>
                <input type="number" className="form-input" defaultValue={1000} />
              </div>
              <div className="form-group">
                <label className="form-label">System Instructions</label>
                <textarea className="form-input" rows={5} defaultValue="You are ClinicConnect AI, a helpful healthcare assistant. Analyze symptoms and recommend appropriate specialists. Always advise consulting a real doctor." />
              </div>
              <hr className="divider" />
              <div className="avail-grid">
                {[
                  ['Enable AI Chatbot for Patients', aiEnabled, () => setAiEnabled(p => !p)],
                  ['Enable Web Search',              webSearch, () => setWebSearch(p => !p)],
                ].map(([label, val, fn]) => (
                  <div key={label} className="avail-row">
                    <span style={{ fontWeight: 600, fontSize: '0.875rem' }}>{label}</span>
                    <label className="toggle">
                      <input type="checkbox" checked={val} onChange={fn} />
                      <span className="toggle-slider" />
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Notifications ── */}
      {page === 'notifications' && (
        <div className="page-section active">
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-bell" style={{ color: 'var(--primary)' }} /> Notifications</span>
              <button className="btn btn-outline-gray btn-sm" onClick={() => showToast('All marked as read', 'success')}>
                Mark all read
              </button>
            </div>
            <div className="card-body" style={{ padding: 0 }}>
              {NOTIFICATIONS.map((n, i) => (
                <div key={i} style={{ display: 'flex', gap: '1rem', padding: '1rem 1.4rem', borderBottom: i < NOTIFICATIONS.length - 1 ? '1px solid var(--border)' : 'none', alignItems: 'flex-start', transition: 'background var(--transition)', cursor: 'pointer' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-main)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'white'}>
                  <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'var(--bg-main)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.1rem', flexShrink: 0, border: '1px solid var(--border)' }}>
                    {n.icon}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: '0.875rem', marginBottom: '0.2rem' }}>{n.title}</div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{n.desc}</div>
                  </div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', whiteSpace: 'nowrap', marginTop: '0.15rem' }}>{n.time}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Settings ── */}
      {page === 'settings' && (
        <div className="page-section active">
          <div className="profile-header-card">
            <div className="profile-avatar-lg" style={{ background: 'linear-gradient(135deg, #7c3aed, #a78bfa)' }}>AS</div>
            <div className="profile-header-info">
              <h2>Dr. Admin Singh</h2>
              <p>admin@clinicconnect.com</p>
              <p style={{ marginTop: '0.35rem' }}><Badge variant="danger">Administrator</Badge></p>
            </div>
          </div>
          <div className="card">
            <div className="card-header">
              <span className="card-title"><i className="fa-solid fa-gear" style={{ color: 'var(--primary)' }} /> Platform Settings</span>
              <button className="btn btn-primary btn-sm" onClick={() => showToast('Settings saved!', 'success')}>
                <i className="fa-solid fa-save" /> Save
              </button>
            </div>
            <div className="card-body">
              {[['Platform Name', 'ClinicConnect'], ['Support Email', 'support@clinicconnect.com'], ['Support Phone', '+91 98765 43210'], ['Institution', 'Parul University, Vadodara']].map(([l, v]) => (
                <div key={l} className="form-group"><label className="form-label">{l}</label><input type="text" className="form-input" defaultValue={v} /></div>
              ))}
              <hr className="divider" />
              <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: '1rem' }}>Notification Preferences</h4>
              <div className="avail-grid">
                {['Email notifications for new appointments', 'SMS alerts for doctor verifications', 'Weekly analytics digest', 'Security alerts'].map(label => (
                  <div key={label} className="avail-row">
                    <span style={{ fontSize: '0.875rem' }}>{label}</span>
                    <label className="toggle"><input type="checkbox" defaultChecked /><span className="toggle-slider" /></label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </DashboardShell>
  )
}
