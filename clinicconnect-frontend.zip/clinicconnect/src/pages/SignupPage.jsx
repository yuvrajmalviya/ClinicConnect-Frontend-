import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'
import { useCountdown } from '../hooks/index'
import Logo from '../components/common/Logo'
import OTPInput from '../components/auth/OTPInput'
import StepIndicator from '../components/auth/StepIndicator'
import Spinner from '../components/common/Spinner'
import '../styles/auth.css'

const ROLE_BTNS = [
  { key: 'patient', label: 'Patient', faIcon: 'fa-solid fa-user-injured' },
  { key: 'doctor',  label: 'Doctor',  faIcon: 'fa-solid fa-stethoscope'  },
]

const REDIRECT = { patient: '/patient', doctor: '/doctor' }

export default function SignupPage() {
  const [role,   setRole]   = useState('patient')
  const [step,   setStep]   = useState(1)
  const [otp,    setOtp]    = useState(['', '', '', '', '', ''])
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    name: '', email: '', phone: '', age: '', gender: '', city: '', address: '',
    spec: '', qual: '', exp: '', reg: '', pwd: '', confirmPwd: '',
  })

  const countdown = useCountdown(30)
  const { login }     = useAuth()
  const { showToast } = useToast()
  const navigate      = useNavigate()

  const setField = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const goStep = (n) => setStep(n)

  const sendOTP = () => {
    if (!form.email) { showToast('Please enter your email first', 'error'); return }
    goStep(3)
    countdown.start()
    showToast(`OTP sent to ${form.email}`, 'success')
  }

  const verify = () => {
    const code = otp.join('')
    if (code.length < 6) { showToast('Please enter the 6-digit OTP', 'error'); return }
    setLoading(true)
    setTimeout(() => {
      login(role)
      showToast('Account created successfully! Welcome 🎉', 'success')
      navigate(REDIRECT[role])
    }, 900)
  }

  const inputField = (key, label, type = 'text', placeholder = '') => (
    <div className="form-group" key={key}>
      <label className="form-label">{label}</label>
      <input type={type} className="form-input" placeholder={placeholder} value={form[key]} onChange={e => setField(key, e.target.value)} />
    </div>
  )

  return (
    <div className="auth-page">
      <Link to="/" className="auth-logo"><Logo /></Link>

      <div className="auth-card wide fade-up">
        <h1 className="auth-title">Create Account</h1>
        <p className="auth-subtitle">Sign up to get started with ClinicConnect</p>

        {/* Role tabs */}
        <div className="role-selector">
          {ROLE_BTNS.map(r => (
            <button key={r.key} type="button" className={`role-btn ${role === r.key ? 'active' : ''}`} onClick={() => setRole(r.key)}>
              <i className={r.faIcon} /> {r.label}
            </button>
          ))}
        </div>

        <StepIndicator steps={['Info', 'Review', 'OTP']} current={step} />

        {/* ── Step 1 ── */}
        {step === 1 && (
          <div className="signup-step active">
            <div className="form-grid-2">
              {inputField('name',  'Full Name',  'text',   role === 'doctor' ? 'Dr. John Doe' : 'Amit Kumar')}
              {inputField('email', 'Email',      'email',  'you@example.com')}
              {inputField('phone', 'Phone',      'tel',    '+91 9876543210')}
              {inputField('city',  'City',       'text',   'Mumbai')}
              {role === 'patient' && inputField('age',   'Age',    'number', '25')}
              {role === 'patient' && (
                <div className="form-group">
                  <label className="form-label">Gender</label>
                  <select className="form-input" value={form.gender} onChange={e => setField('gender', e.target.value)}>
                    <option value="">Select Gender</option>
                    <option>Male</option><option>Female</option><option>Other</option>
                  </select>
                </div>
              )}
            </div>
            <div className="form-group">
              <label className="form-label">Address</label>
              <input type="text" className="form-input" placeholder="123, Street Name, Area" value={form.address} onChange={e => setField('address', e.target.value)} />
            </div>

            {role === 'doctor' && (
              <>
                <hr className="divider" />
                <p style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>Professional Details</p>
                <div className="form-grid-2">
                  {inputField('spec', 'Specialization',      'text', 'Cardiologist')}
                  {inputField('qual', 'Qualification',        'text', 'MBBS, MD')}
                  {inputField('exp',  'Experience (years)',   'number', '5')}
                  {inputField('reg',  'Registration No.',     'text', 'MH12345')}
                </div>
              </>
            )}

            <div className="form-group">
              <label className="form-label">Password</label>
              <input type="password" className="form-input" placeholder="Min 8 characters" value={form.pwd} onChange={e => setField('pwd', e.target.value)} />
            </div>

            <button className="btn btn-primary btn-full btn-lg" onClick={() => goStep(2)}>
              Continue <i className="fa-solid fa-arrow-right" />
            </button>
          </div>
        )}

        {/* ── Step 2 ── */}
        {step === 2 && (
          <div className="signup-step active">
            <div style={{ background: 'var(--bg-main)', borderRadius: 'var(--radius-md)', padding: '1rem 1.1rem', marginBottom: '1.25rem', border: '1px solid var(--border)' }}>
              <p style={{ fontSize: '0.82rem', fontWeight: 700, marginBottom: '0.75rem', color: 'var(--text-secondary)' }}>Review Your Details</p>
              {[['Name', form.name], ['Email', form.email], ['Phone', form.phone], ['City', form.city], ['Role', role]].map(([k, v]) => (
                <div key={k} style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', marginBottom: '0.3rem', display: 'flex', gap: '0.5rem' }}>
                  <strong style={{ color: 'var(--text-primary)', minWidth: 55 }}>{k}:</strong> {v || '—'}
                </div>
              ))}
            </div>
            <div className="form-group">
              <label className="form-label">Confirm Password</label>
              <input type="password" className="form-input" placeholder="Re-enter your password" value={form.confirmPwd} onChange={e => setField('confirmPwd', e.target.value)} />
            </div>
            <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginBottom: '1.1rem' }}>
              By continuing you agree to our{' '}
              <a href="#" style={{ color: 'var(--primary)' }}>Terms of Service</a> and{' '}
              <a href="#" style={{ color: 'var(--primary)' }}>Privacy Policy</a>.
            </p>
            <div style={{ display: 'flex', gap: '0.75rem' }}>
              <button className="btn btn-outline-gray btn-lg" style={{ flex: 1, justifyContent: 'center' }} onClick={() => goStep(1)}>
                <i className="fa-solid fa-arrow-left" /> Back
              </button>
              <button className="btn btn-primary btn-lg" style={{ flex: 1, justifyContent: 'center' }} onClick={sendOTP}>
                Send OTP <i className="fa-solid fa-paper-plane" />
              </button>
            </div>
          </div>
        )}

        {/* ── Step 3 ── */}
        {step === 3 && (
          <div className="signup-step active">
            <div style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
              <div style={{ width: 60, height: 60, borderRadius: '50%', background: 'var(--primary-xlight)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem', fontSize: '1.5rem' }}>
                ✉️
              </div>
              <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 700, marginBottom: '0.35rem' }}>Check Your Email</h3>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
                We sent a 6-digit OTP to <strong>{form.email || 'your email'}</strong>
              </p>
            </div>

            <OTPInput value={otp} onChange={setOtp} />

            <div className="resend-timer" style={{ marginBottom: '1.25rem' }}>
              {countdown.finished
                ? <span style={{ color: 'var(--primary)', fontWeight: 600, cursor: 'pointer' }} onClick={() => { countdown.start(); showToast('OTP resent!', 'info') }}>Resend OTP</span>
                : <>Resend OTP in <strong>{countdown.count}s</strong></>
              }
            </div>

            <div style={{ display: 'flex', gap: '0.75rem' }}>
              <button className="btn btn-outline-gray btn-lg" style={{ flex: 1, justifyContent: 'center' }} onClick={() => goStep(2)}>
                <i className="fa-solid fa-arrow-left" /> Back
              </button>
              <button className="btn btn-primary btn-lg" style={{ flex: 1, justifyContent: 'center' }} onClick={verify} disabled={loading}>
                {loading ? <><Spinner /> Verifying...</> : <><i className="fa-solid fa-check" /> Verify & Register</>}
              </button>
            </div>
          </div>
        )}

        <p style={{ textAlign: 'center', fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '1.5rem' }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color: 'var(--primary)', fontWeight: 600 }}>Login</Link>
        </p>
      </div>
    </div>
  )
}
