import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { useToast } from '../../context/ToastContext'
import Logo from '../common/Logo'
import '../../styles/dashboard.css'

export default function DashboardShell({ navItems, activePage, setActivePage, children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const { currentUser, logout } = useAuth()
  const { showToast } = useToast()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    showToast('Logged out successfully', 'info')
    navigate('/login')
  }

  const handleNotif = () => showToast('No new notifications', 'info')

  return (
    <div className="dashboard-layout">
      {/* ── Sidebar ── */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <Logo theme="dark" size="sm" />
        </div>

        <nav className="sidebar-nav">
          <div className="sidebar-section-label">Navigation</div>
          {navItems.map(item => (
            <a
              key={item.key}
              className={activePage === item.key ? 'active' : ''}
              onClick={() => { setActivePage(item.key); setSidebarOpen(false) }}
            >
              <span className="nav-icon">
                <i className={item.faIcon} />
              </span>
              <span>{item.label}</span>
              {item.badge ? <span className="nav-badge">{item.badge}</span> : null}
            </a>
          ))}
        </nav>

        <div className="sidebar-footer">
          <a onClick={handleLogout}>
            <span className="nav-icon"><i className="fa-solid fa-right-from-bracket" /></span>
            <span>Logout</span>
          </a>
        </div>
      </aside>

      {/* Overlay */}
      <div
        className={`sidebar-overlay visible ${sidebarOpen ? 'open' : ''}`}
        onClick={() => setSidebarOpen(false)}
      />

      {/* ── Main ── */}
      <div className="dashboard-main">
        <header className="dashboard-header">
          <div className="dash-header-left">
            <span className="mobile-sidebar-toggle" onClick={() => setSidebarOpen(true)}>
              <i className="fa-solid fa-bars" />
            </span>
            <span className="dash-page-title">
              {navItems.find(n => n.key === activePage)?.label || 'Dashboard'}
            </span>
          </div>

          <div className="dash-header-right">
            <div className="notif-btn" onClick={handleNotif}>
              <i className="fa-solid fa-bell" />
              {currentUser?.notifs > 0 && (
                <span className="notif-badge">{currentUser.notifs}</span>
              )}
            </div>

            <div className="user-info">
              <div className="user-avatar">{currentUser?.initials || '?'}</div>
              <div>
                <div className="user-name">{currentUser?.name || 'User'}</div>
                <div className="user-role">{currentUser?.role || ''}</div>
              </div>
            </div>

            <div className="logout-btn" onClick={handleLogout} title="Logout">
              <i className="fa-solid fa-right-from-bracket" />
            </div>
          </div>
        </header>

        <div className="dashboard-content">
          {children}
        </div>
      </div>
    </div>
  )
}
