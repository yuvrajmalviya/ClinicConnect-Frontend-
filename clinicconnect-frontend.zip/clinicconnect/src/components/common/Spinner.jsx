export default function Spinner({ size = 'sm', dark = false }) {
  const sizes = { sm: 18, md: 24, lg: 36 }
  const px = sizes[size] || sizes.sm
  return (
    <span
      className={dark ? 'spinner spinner-dark' : 'spinner'}
      style={{ width: px, height: px }}
      aria-label="Loading"
    />
  )
}
