import { useState } from 'react'
import Modal from '../common/Modal'
import { TIME_SLOTS } from '../../data/mockData'
import { useToast } from '../../context/ToastContext'

export default function BookingModal({ open, doctor, onClose, onConfirm }) {
  const [mode, setMode] = useState('online')
  const [date, setDate] = useState('')
  const [slot, setSlot] = useState('')
  const { showToast } = useToast()

  const today = new Date().toISOString().split('T')[0]

  const handleConfirm = () => {
    if (!date) { showToast('Please select a date', 'error'); return }
    if (!slot)  { showToast('Please select a time slot', 'error'); return }
    onConfirm?.({ doctor, date, slot, mode })
    setDate(''); setSlot(''); setMode('online')
  }

  const footer = (
    <>
      <button className="btn btn-outline-gray" onClick={onClose}>Cancel</button>
      <button className="btn btn-primary" onClick={handleConfirm}>
        <i className="fa-solid fa-check" /> Confirm Booking
      </button>
    </>
  )

  return (
    <Modal open={open} onClose={onClose} title={`Book – ${doctor?.name || ''}`} footer={footer}>
      {/* Mode */}
      <h4 style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-secondary)', marginBottom: '0.75rem' }}>
        Consultation Mode
      </h4>
      <div className="mode-options">
        {[
          { key: 'online',  icon: '💻', title: 'Online',    desc: 'Video / Audio Call' },
          { key: 'clinic',  icon: '🏥', title: 'In-Clinic', desc: 'Visit in person'    },
        ].map(m => (
          <div
            key={m.key}
            className={`mode-option ${mode === m.key ? 'selected' : ''}`}
            onClick={() => setMode(m.key)}
          >
            <div className="mode-option-icon">{m.icon}</div>
            <div className="mode-option-title">{m.title}</div>
            <div className="mode-option-desc">{m.desc}</div>
          </div>
        ))}
      </div>

      {/* Date */}
      <h4 style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-secondary)', marginBottom: '0.6rem' }}>
        Select Date
      </h4>
      <input
        type="date"
        className="form-input"
        value={date}
        min={today}
        onChange={e => setDate(e.target.value)}
        style={{ marginBottom: '1.25rem' }}
      />

      {/* Slots */}
      <h4 style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--text-secondary)', marginBottom: '0.6rem' }}>
        Available Slots
      </h4>
      <div className="slots-grid">
        {TIME_SLOTS.map(s => (
          <div
            key={s.time}
            className={[
              'slot-item',
              !s.available ? 'unavailable' : '',
              slot === s.time ? 'selected' : '',
            ].join(' ')}
            onClick={() => s.available && setSlot(s.time)}
          >
            {s.time}
          </div>
        ))}
      </div>
    </Modal>
  )
}
