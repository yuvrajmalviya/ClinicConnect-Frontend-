import { Navigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

export default function ProtectedRoute({ children, role }) {
  const { currentUser } = useAuth()

  // If no user is logged in, redirect to login
  if (!currentUser) {
    return <Navigate to="/login" replace />
  }

  // If user role doesn't match the required role, redirect to their dashboard
  if (role && currentUser.role.toLowerCase() !== role.toLowerCase()) {
    const redirects = {
      patient: '/patient',
      doctor:  '/doctor',
      admin:   '/admin',
    }
    return <Navigate to={redirects[currentUser.role.toLowerCase()] || '/login'} replace />
  }

  return children
}
