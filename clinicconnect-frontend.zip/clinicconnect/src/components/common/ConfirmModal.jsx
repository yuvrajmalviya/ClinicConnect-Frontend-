import Modal from './Modal'

export default function ConfirmModal({ open, onClose, details, onViewAppointments }) {
  return (
    <Modal open={open} onClose={onClose} maxWidth={360}>
      <div style={{ textAlign: 'center', padding: '0.5rem 0' }}>
        <div style={{
          width: 64, height: 64, borderRadius: '50%',
          background: 'var(--success-light)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 1.1rem',
          fontSize: '1.8rem',
        }}>
          ✓
        </div>
        <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.1rem', marginBottom: '0.5rem' }}>
          Appointment Confirmed!
        </h3>
        <p style={{ fontSize: '0.84rem', color: 'var(--text-muted)', marginBottom: '1.5rem', lineHeight: 1.6 }}>
          {details}
        </p>
        <button className="btn btn-primary btn-full" onClick={onViewAppointments}>
          <i className="fa-solid fa-calendar-check" /> View Appointments
        </button>
      </div>
    </Modal>
  )
}
