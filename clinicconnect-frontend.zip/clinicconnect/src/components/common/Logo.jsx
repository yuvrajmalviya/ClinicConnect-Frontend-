import { Link } from 'react-router-dom'

export default function Logo({ onClick, size = 'md', theme = 'light' }) {
  const sizes = { sm: { svg: 20, text: '1rem' }, md: { svg: 26, text: '1.2rem' }, lg: { svg: 30, text: '1.4rem' } }
  const s = sizes[size] || sizes.md
  const textColor = theme === 'dark' ? 'white' : 'var(--text-primary)'

  const content = (
    <>
      <svg viewBox="0 0 28 28" fill="none" style={{ width: s.svg, height: s.svg, flexShrink: 0 }}>
        <polyline
          points="1,14 6,7 10,18 14,4 18,20 22,11 27,14"
          stroke={theme === 'dark' ? '#06b6d4' : '#1a56db'}
          strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round"
        />
      </svg>
      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: s.text, color: textColor }}>
        Clinic<span style={{ color: '#06b6d4' }}>Connect</span>
      </span>
    </>
  )

  const style = { display: 'flex', alignItems: 'center', gap: '0.55rem', cursor: 'pointer', textDecoration: 'none' }

  if (onClick) {
    return <div style={style} onClick={onClick}>{content}</div>
  }

  return <Link to="/" style={style}>{content}</Link>
}
