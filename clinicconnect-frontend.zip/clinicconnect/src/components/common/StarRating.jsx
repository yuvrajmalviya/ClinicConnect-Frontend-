import { useState } from 'react'

export default function StarRating({ value = 0, onChange, readOnly = false, size = '1.5rem' }) {
  const [hovered, setHovered] = useState(0)

  return (
    <div style={{ display: 'flex', gap: '0.3rem', fontSize: size }}>
      {[1, 2, 3, 4, 5].map(n => (
        <span
          key={n}
          style={{
            cursor: readOnly ? 'default' : 'pointer',
            color: n <= (hovered || value) ? '#fbbf24' : '#e5e7eb',
            transition: 'color 0.15s',
            lineHeight: 1,
          }}
          onClick={() => !readOnly && onChange?.(n)}
          onMouseEnter={() => !readOnly && setHovered(n)}
          onMouseLeave={() => !readOnly && setHovered(0)}
        >
          ★
        </span>
      ))}
    </div>
  )
}
