import Badge from '../common/Badge'

export default function DoctorCard({ doc, onBook }) {
  return (
    <div className="doctor-card fade-up">
      <div className="doctor-card-header">
        <div style={{ display: 'flex', gap: '0.65rem', alignItems: 'flex-start', flex: 1, minWidth: 0 }}>
          <div
            className="doctor-avatar"
            style={{ background: `linear-gradient(135deg, ${doc.color?.[0] || '#1a56db'}, ${doc.color?.[1] || '#06b6d4'})` }}
          >
            {doc.initials}
          </div>
          <div style={{ minWidth: 0 }}>
            <div className="doctor-name" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {doc.name}
            </div>
            <div className="doctor-spec">{doc.spec}</div>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '0.25rem', flexShrink: 0 }}>
          <div className="doctor-rating">⭐ {doc.rating}</div>
          <Badge variant={doc.available ? 'success' : 'neutral'}>
            {doc.available ? 'Available' : 'Busy'}
          </Badge>
        </div>
      </div>

      <p className="doctor-bio">{doc.bio}</p>

      <div className="doctor-card-meta">
        <div className="doctor-meta-item">
          <i className="fa-solid fa-location-dot" style={{ fontSize: '0.7rem', color: 'var(--primary)' }} />
          {doc.city}
        </div>
        <div className="doctor-meta-item">
          <i className="fa-solid fa-indian-rupee-sign" style={{ fontSize: '0.7rem', color: 'var(--success)' }} />
          {doc.fees.replace('₹', '')}
        </div>
        <div className="doctor-meta-item">
          <i className="fa-solid fa-hospital" style={{ fontSize: '0.7rem', color: 'var(--accent)' }} />
          {doc.mode}
        </div>
        <div className="doctor-meta-item">
          <i className="fa-solid fa-clock" style={{ fontSize: '0.7rem', color: 'var(--warning)' }} />
          {doc.hours}
        </div>
      </div>

      <div style={{ display: 'flex', gap: '0.5rem' }}>
        <button
          className="btn btn-outline btn-sm"
          style={{ flex: 1, justifyContent: 'center' }}
          onClick={() => {/* view profile */}}
        >
          <i className="fa-solid fa-user" /> Profile
        </button>
        <button
          className="btn btn-primary"
          style={{ flex: 2, justifyContent: 'center' }}
          disabled={!doc.available}
          onClick={() => onBook(doc)}
        >
          <i className="fa-solid fa-calendar-plus" /> Book
        </button>
      </div>
    </div>
  )
}
