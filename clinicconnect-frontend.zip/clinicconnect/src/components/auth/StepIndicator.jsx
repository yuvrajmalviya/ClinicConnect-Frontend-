export default function StepIndicator({ steps, current }) {
  return (
    <div className="step-indicator">
      {steps.map((label, i) => {
        const n = i + 1
        const isDone   = n < current
        const isActive = n === current
        return (
          <div key={n} className={`step-dot ${isActive ? 'active' : ''} ${isDone ? 'done' : ''}`}>
            <div className="step-dot-circle">{isDone ? '✓' : n}</div>
            <div className="step-dot-label">{label}</div>
          </div>
        )
      })}
    </div>
  )
}
