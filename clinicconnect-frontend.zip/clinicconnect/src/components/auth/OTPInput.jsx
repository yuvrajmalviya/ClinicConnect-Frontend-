import { useRef } from 'react'

export default function OTPInput({ value, onChange }) {
  const refs = useRef([])

  const handleChange = (idx, val) => {
    const cleaned = val.replace(/\D/g, '').slice(0, 1)
    const next = [...value]
    next[idx] = cleaned
    onChange(next)
    if (cleaned && idx < 5) refs.current[idx + 1]?.focus()
  }

  const handleKeyDown = (idx, e) => {
    if (e.key === 'Backspace' && !value[idx] && idx > 0) {
      refs.current[idx - 1]?.focus()
    }
  }

  const handlePaste = (e) => {
    e.preventDefault()
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6)
    const next = [...value]
    for (let i = 0; i < pasted.length; i++) next[i] = pasted[i]
    onChange(next)
    refs.current[Math.min(pasted.length, 5)]?.focus()
  }

  return (
    <div className="otp-grid">
      {value.map((v, i) => (
        <input
          key={i}
          ref={el => refs.current[i] = el}
          type="text"
          inputMode="numeric"
          className={`otp-input ${v ? 'filled' : ''}`}
          maxLength={1}
          value={v}
          onChange={e => handleChange(i, e.target.value)}
          onKeyDown={e => handleKeyDown(i, e)}
          onPaste={handlePaste}
          autoComplete="off"
        />
      ))}
    </div>
  )
}
