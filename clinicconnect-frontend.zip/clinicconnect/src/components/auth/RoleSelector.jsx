export default function RoleSelector({ roles, selected, onChange }) {
  return (
    <div className="role-selector">
      {roles.map(r => (
        <button
          key={r.key}
          type="button"
          className={`role-btn ${selected === r.key ? 'active' : ''}`}
          onClick={() => onChange(r.key)}
        >
          <i className={r.faIcon} />
          {r.label}
        </button>
      ))}
    </div>
  )
}
