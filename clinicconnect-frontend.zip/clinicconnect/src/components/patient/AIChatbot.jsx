import { useState, useRef, useEffect } from 'react'
import { useToast } from '../../context/ToastContext'
import '../../styles/chatbot.css'

const QUICK_SYMPTOMS = ['Headache', 'Fever', 'Chest Pain', 'Back Pain', 'Cough', 'Skin Rash']

export default function AIChatbot({ onSpecialistClick }) {
  const [messages, setMessages] = useState([{
    role: 'bot',
    text: "Hello! I'm your AI health assistant powered by Claude. Describe your symptoms and I'll help you find the right specialist. 😊",
    time: 'Just now',
  }])
  const [input,   setInput]   = useState('')
  const [loading, setLoading] = useState(false)
  const [specialist, setSpecialist] = useState(null)
  const endRef = useRef(null)
  const { showToast } = useToast()

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages, loading])

  const now = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })

  const addMsg = (role, text) =>
    setMessages(p => [...p, { role, text, time: now() }])

  const sendMessage = async (text) => {
    const msg = (text || input).trim()
    if (!msg || loading) return
    setInput('')
    addMsg('user', msg)
    setLoading(true)
    setSpecialist(null)

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: `You are ClinicConnect AI, a compassionate healthcare assistant. When a user describes symptoms:
1. Acknowledge their concern with empathy (1 sentence)
2. List 2-3 possible explanations (brief, non-alarming)
3. Recommend a specific medical specialization
4. Give 1-2 self-care tips
5. Always say "Please consult a real doctor for diagnosis"
6. End with exactly: "SPECIALIST: [specialization name]" on its own line

Keep response under 120 words. Be warm but professional.`,
          messages: [{ role: 'user', content: msg }],
        }),
      })

      const data = await res.json()
      const full = data.content?.[0]?.text || 'I had trouble processing that. Please try again.'
      const match = full.match(/SPECIALIST:\s*(.+)/i)
      const spec  = match?.[1]?.trim()
      const display = full.replace(/SPECIALIST:.*/is, '').trim()

      addMsg('bot', display)
      if (spec) setSpecialist(spec)
    } catch {
      addMsg('bot', "I'm having trouble connecting right now. Please check your network and try again.")
      showToast('AI connection error', 'error')
    }

    setLoading(false)
  }

  return (
    <div className="chatbot-wrapper">
      <div className="chatbot-container">
        {/* Header */}
        <div className="chat-header">
          <div className="chat-header-avatar">🤖</div>
          <div className="chat-header-info">
            <h3>ClinicConnect AI</h3>
            <div className="chat-status">
              <span className="chat-status-dot" />
              Online – Ready to help
              <span className="chat-model-badge">Claude Sonnet</span>
            </div>
          </div>
        </div>

        {/* Quick symptom chips */}
        <div className="quick-chips">
          {QUICK_SYMPTOMS.map(s => (
            <span key={s} className="quick-chip" onClick={() => sendMessage(s)}>{s}</span>
          ))}
        </div>

        {/* Messages */}
        <div className="chat-messages">
          {messages.map((m, i) => (
            <div key={i} className={`chat-message ${m.role}`}>
              <div className="chat-msg-avatar">
                {m.role === 'bot' ? '🤖' : 'AK'}
              </div>
              <div className="chat-msg-content">
                <div className="chat-msg-bubble" style={{ whiteSpace: 'pre-wrap' }}>{m.text}</div>
                <div className="chat-msg-time">{m.time}</div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="chat-message bot">
              <div className="chat-msg-avatar">🤖</div>
              <div className="chat-msg-content">
                <div className="chat-msg-bubble">
                  <div className="chat-typing">
                    <span /><span /><span />
                  </div>
                </div>
              </div>
            </div>
          )}

          {specialist && (
            <div className="chat-message bot">
              <div className="chat-msg-avatar">🤖</div>
              <div className="chat-msg-content">
                <div className="spec-suggestion-card">
                  <h4>💡 Recommended Specialization</h4>
                  <span className="spec-tag" onClick={() => { onSpecialistClick?.(specialist); setSpecialist(null) }}>
                    <i className="fa-solid fa-stethoscope" /> {specialist}
                  </span>
                  <p className="spec-hint">Click to find doctors in this specialty →</p>
                </div>
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        {/* Input */}
        <div className="chat-input-area">
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
            placeholder="Describe your symptoms..."
            disabled={loading}
          />
          <button className="chat-send-btn" onClick={() => sendMessage()} disabled={loading || !input.trim()}>
            <i className="fa-solid fa-paper-plane" />
          </button>
        </div>
      </div>
    </div>
  )
}
