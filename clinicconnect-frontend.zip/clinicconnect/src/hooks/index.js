import { useState, useEffect, useCallback, useRef } from 'react'

// ── useToggle ────────────────────────────────────────────────
export function useToggle(initial = false) {
  const [value, setValue] = useState(initial)
  const toggle = useCallback(() => setValue(v => !v), [])
  const setTrue  = useCallback(() => setValue(true),  [])
  const setFalse = useCallback(() => setValue(false), [])
  return [value, { toggle, setTrue, setFalse, set: setValue }]
}

// ── useModal ─────────────────────────────────────────────────
export function useModal() {
  const [isOpen, setIsOpen] = useState(false)
  const [data, setData]     = useState(null)

  const open  = useCallback((d = null) => { setData(d); setIsOpen(true)  }, [])
  const close = useCallback(()         => { setIsOpen(false)             }, [])

  return { isOpen, data, open, close }
}

// ── useCountdown ─────────────────────────────────────────────
export function useCountdown(initial = 30) {
  const [count, setCount]     = useState(initial)
  const [running, setRunning] = useState(false)
  const timerRef = useRef(null)

  const start = useCallback((from = initial) => {
    if (timerRef.current) clearInterval(timerRef.current)
    setCount(from)
    setRunning(true)
    timerRef.current = setInterval(() => {
      setCount(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current)
          setRunning(false)
          return 0
        }
        return prev - 1
      })
    }, 1000)
  }, [initial])

  const reset = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current)
    setCount(initial)
    setRunning(false)
  }, [initial])

  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current) }, [])

  return { count, running, start, reset, finished: count === 0 }
}

// ── useScroll ─────────────────────────────────────────────────
export function useScroll(threshold = 20) {
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > threshold)
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [threshold])
  return scrolled
}

// ── useFilter ─────────────────────────────────────────────────
export function useFilter(items, filterFn) {
  const [query,   setQuery]   = useState('')
  const [spec,    setSpec]    = useState('')
  const [city,    setCity]    = useState('')

  const filtered = items.filter(item => filterFn(item, { query, spec, city }))

  return { query, setQuery, spec, setSpec, city, setCity, filtered }
}
