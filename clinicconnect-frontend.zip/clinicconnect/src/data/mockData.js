// ============================================================
//  Static Mock Data
// ============================================================

export const DOCTORS = [
  {
    id: 1,
    name: 'Dr. Priya Sharma',
    spec: 'Cardiologist',
    rating: '4.8',
    reviews: 124,
    city: 'Mumbai',
    fees: '₹800',
    mode: 'Both',
    hours: '10:00 AM – 5:00 PM',
    initials: 'PS',
    color: ['#1a56db', '#06b6d4'],
    bio: 'Expert cardiologist with 12 years of clinical experience in interventional cardiology.',
    available: true,
  },
  {
    id: 2,
    name: 'Dr. Rahul Verma',
    spec: 'Dermatologist',
    rating: '4.5',
    reviews: 89,
    city: 'Delhi',
    fees: '₹600',
    mode: 'Online',
    hours: '11:00 AM – 7:00 PM',
    initials: 'RV',
    color: ['#7c3aed', '#a78bfa'],
    bio: 'Specializes in cosmetic and medical dermatology, acne, and skin disorders.',
    available: true,
  },
  {
    id: 3,
    name: 'Dr. Anita Patel',
    spec: 'Pediatrician',
    rating: '4.9',
    reviews: 201,
    city: 'Bangalore',
    fees: '₹500',
    mode: 'Both',
    hours: '9:00 AM – 4:00 PM',
    initials: 'AP',
    color: ['#16a34a', '#4ade80'],
    bio: 'Dedicated pediatrician with expertise in child development and immunization.',
    available: true,
  },
  {
    id: 4,
    name: 'Dr. Vikram Reddy',
    spec: 'Neurologist',
    rating: '4.6',
    reviews: 76,
    city: 'Hyderabad',
    fees: '₹900',
    mode: 'Both',
    hours: '10:00 AM – 6:00 PM',
    initials: 'VR',
    color: ['#dc2626', '#f87171'],
    bio: 'Neurologist specializing in epilepsy, migraines, and movement disorders.',
    available: false,
  },
  {
    id: 5,
    name: 'Dr. Sanjay Gupta',
    spec: 'Orthopedic',
    rating: '4.7',
    reviews: 143,
    city: 'Mumbai',
    fees: '₹700',
    mode: 'In-Clinic',
    hours: '9:00 AM – 3:00 PM',
    initials: 'SG',
    color: ['#d97706', '#fbbf24'],
    bio: 'Orthopedic surgeon specializing in joint replacement and sports injuries.',
    available: true,
  },
  {
    id: 6,
    name: 'Dr. Meena Iyer',
    spec: 'General Physician',
    rating: '4.4',
    reviews: 312,
    city: 'Chennai',
    fees: '₹400',
    mode: 'Both',
    hours: '8:00 AM – 8:00 PM',
    initials: 'MI',
    color: ['#0891b2', '#22d3ee'],
    bio: 'General physician with expertise in preventive care and chronic disease management.',
    available: true,
  },
]

export const SPECIALIZATIONS = [
  'Cardiologist',
  'Dermatologist',
  'Pediatrician',
  'Neurologist',
  'Orthopedic',
  'General Physician',
  'Gynecologist',
  'Psychiatrist',
  'Ophthalmologist',
  'ENT Specialist',
]

export const APPOINTMENTS = [
  {
    id: 'apt-1',
    doctor: 'Dr. Priya Sharma',
    spec: 'Cardiologist',
    date: '2026-03-25',
    time: '10:30 AM',
    mode: 'Online',
    status: 'Booked',
  },
  {
    id: 'apt-2',
    doctor: 'Dr. Anita Patel',
    spec: 'Pediatrician',
    date: '2026-03-10',
    time: '9:00 AM',
    mode: 'In-Clinic',
    status: 'Completed',
  },
]

export const PRESCRIPTIONS = [
  {
    id: 'rx-1',
    doctor: 'Dr. Priya Sharma',
    spec: 'Cardiologist',
    date: '20 March 2026',
    medicines: [
      { name: 'Aspirin 75mg', instruction: 'Once daily after breakfast', duration: '30 days' },
      { name: 'Metoprolol 25mg', instruction: 'Twice daily', duration: '30 days' },
    ],
    notes: 'Avoid fatty foods. Follow up after 1 month.',
  },
]

export const LAB_REPORTS = [
  { id: 'lab-1', test: 'Complete Blood Count', date: '2026-03-18', lab: 'Apollo Diagnostics', orderedBy: 'Dr. Priya Sharma', status: 'Ready' },
  { id: 'lab-2', test: 'Lipid Profile', date: '2026-03-20', lab: 'SRL Diagnostics', orderedBy: 'Dr. Priya Sharma', status: 'Pending' },
]

export const DEMO_CREDENTIALS = {
  admin:   { email: 'admin@clinicconnect.com',   password: 'admin123'   },
  doctor:  { email: 'doctor@clinicconnect.com',  password: 'doctor123'  },
  patient: { email: 'patient@clinicconnect.com', password: 'patient123' },
}

export const TIME_SLOTS = [
  { time: '10:00 AM', available: true  },
  { time: '10:30 AM', available: true  },
  { time: '11:00 AM', available: false },
  { time: '11:30 AM', available: true  },
  { time: '2:00 PM',  available: true  },
  { time: '3:00 PM',  available: true  },
  { time: '4:00 PM',  available: false },
  { time: '5:00 PM',  available: true  },
]

export const ADMIN_STATS = {
  totalDoctors: 6,
  totalPatients: 4,
  todayAppointments: 3,
  pendingVerifications: 2,
  totalRevenue: '₹3,41,000',
  avgRating: '4.7',
}

export const REVENUE_DATA = [
  { month: 'Sep', value: 45 },
  { month: 'Oct', value: 49 },
  { month: 'Nov', value: 47 },
  { month: 'Dec', value: 62 },
  { month: 'Jan', value: 55 },
  { month: 'Feb', value: 68 },
  { month: 'Mar', value: 72 },
]

export const PENDING_VERIFICATIONS = [
  { name: 'Dr. Arjun Mehta',  spec: 'Neurologist',   reg: 'DL54321',  exp: '8 yrs',  qual: 'MBBS, DM',   initials: 'AM' },
  { name: 'Dr. Sunita Roy',   spec: 'Gynecologist',  reg: 'WB12345',  exp: '12 yrs', qual: 'MBBS, MD',   initials: 'SR' },
]
