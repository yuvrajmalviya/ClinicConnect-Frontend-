import { createContext, useContext, useState } from 'react'

const AuthContext = createContext(null)

const USER_PROFILES = {
  patient: { name: 'Amit Kumar',        role: 'Patient', initials: 'AK', email: 'patient@clinicconnect.com', notifs: 2 },
  doctor:  { name: 'Dr. Priya Sharma',  role: 'Doctor',  initials: 'PS', email: 'doctor@clinicconnect.com',  notifs: 3 },
  admin:   { name: 'Dr. Admin Singh',   role: 'Admin',   initials: 'AS', email: 'admin@clinicconnect.com',   notifs: 5 },
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null)

  const login = (role) => {
    setCurrentUser(USER_PROFILES[role] || null)
  }

  const logout = () => {
    setCurrentUser(null)
  }

  return (
    <AuthContext.Provider value={{ currentUser, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
